-- Prism DIA schema — mirrors the Data Schema section of the design doc verbatim.
-- Enums encode the doc's controlled vocabularies so bad states are impossible.

-- ── Enums ─────────────────────────────────────────────────
CREATE TYPE source_type      AS ENUM ('competitor','analyst','sales','field','slack','internal','press');
CREATE TYPE signal_tier      AS ENUM ('EMERGING','CONFIRMED','ESTABLISHED');
CREATE TYPE decision_type    AS ENUM ('FULL_REPOSITION','MESSAGING_ACCENT','FRAMING_SHIFT','HOLD_WITH_TRIGGER');
CREATE TYPE decision_status  AS ENUM ('OPEN','DECIDED-A','DECIDED-B','DEFERRED','EXPIRED');
CREATE TYPE urgency_level    AS ENUM ('low','medium','high');
CREATE TYPE time_horizon     AS ENUM ('short','medium','long');
CREATE TYPE affected_area    AS ENUM ('narrative','product','pricing','field');
CREATE TYPE review_outcome   AS ENUM ('accurate','inaccurate','inconclusive');
CREATE TYPE decision_model   AS ENUM ('narrative_drift','entry_validity','axis_shift');

-- ── Signal Object (doc §Data Schema) ──────────────────────
CREATE TABLE signal (
    id              TEXT PRIMARY KEY,
    source          source_type NOT NULL,
    source_family   TEXT NOT NULL,                 -- independence dedup key
    timestamp       TIMESTAMPTZ NOT NULL,
    content         TEXT NOT NULL,
    entities        JSONB DEFAULT '[]'::jsonb,     -- ["product","company","theme"]
    tags            JSONB DEFAULT '[]'::jsonb,     -- ["AI","pricing","governance","hybrid"]
    independence_wt NUMERIC(3,2),                   -- assigned by Layer 2 (0.25/0.5/0.75/1.0)
    recency_wt      NUMERIC(3,2),                   -- 0.0/0.5/0.75/1.0
    weighted_score  NUMERIC(4,3) DEFAULT 0,         -- independence_wt * recency_wt
    created_at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_signal_source_family ON signal (source_family);
CREATE INDEX idx_signal_timestamp     ON signal (timestamp);

-- ── Pattern Object ────────────────────────────────────────
CREATE TABLE pattern (
    id           TEXT PRIMARY KEY,
    signal_ids   JSONB NOT NULL DEFAULT '[]'::jsonb,
    summary      TEXT NOT NULL,                     -- "Market is shifting from X to Y because Z"
    direction    TEXT,                              -- "X_to_Y"
    signal_tier  signal_tier NOT NULL,
    source_count INT NOT NULL DEFAULT 0,            -- weighted unique source categories
    created_at   TIMESTAMPTZ DEFAULT now(),
    reviewed     BOOLEAN DEFAULT false              -- manual review gate flag
);

-- ── Constraint Object ─────────────────────────────────────
CREATE TABLE constraint_break (
    id             TEXT PRIMARY KEY,
    pattern_id     TEXT REFERENCES pattern(id),
    assumption_id  TEXT NOT NULL,                   -- FK to positioning config (file-based)
    assumption_text TEXT NOT NULL,
    broken_because TEXT NOT NULL,
    affected_area  affected_area NOT NULL,
    created_at     TIMESTAMPTZ DEFAULT now()
);

-- ── Decision Object ───────────────────────────────────────
CREATE TABLE decision (
    id            TEXT PRIMARY KEY,
    model         decision_model NOT NULL,
    signal        TEXT NOT NULL,
    constraint_txt TEXT NOT NULL,
    decision_type decision_type NOT NULL,
    option_a      TEXT NOT NULL,
    option_b      TEXT NOT NULL,
    b_trigger     TEXT,                              -- REQUIRED if decision_type = HOLD_WITH_TRIGGER
    impact        TEXT,
    urgency       urgency_level,
    time_horizon  time_horizon,
    commit_by     DATE NOT NULL,
    decision_owner TEXT NOT NULL,                    -- named role, never "PMM"
    status        decision_status DEFAULT 'OPEN',
    decided_at    TIMESTAMPTZ,
    notes         TEXT,
    review_30d    review_outcome,
    review_60d    review_outcome,
    review_90d    review_outcome,
    created_at    TIMESTAMPTZ DEFAULT now(),
    -- doc Design Rule: HOLD requires a defined trigger or it is not a valid B
    CONSTRAINT hold_requires_trigger
        CHECK (decision_type <> 'HOLD_WITH_TRIGGER' OR b_trigger IS NOT NULL)
);
CREATE INDEX idx_decision_status    ON decision (status);
CREATE INDEX idx_decision_commit_by ON decision (commit_by);

-- View: decisions past commit_by with no logged response = DEFERRED surface
-- (doc: "no action is a choice" — visible in leadership reporting)
CREATE VIEW v_deferred AS
SELECT id, model, decision_owner, commit_by, status
FROM decision
WHERE status = 'OPEN' AND commit_by < CURRENT_DATE;

-- Performance indexes (v1.1)
-- These are created with IF NOT EXISTS so safe to re-run
CREATE INDEX IF NOT EXISTS idx_signal_source         ON signal(source);
CREATE INDEX IF NOT EXISTS idx_signal_timestamp      ON signal(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_signal_source_family  ON signal(source_family);
CREATE INDEX IF NOT EXISTS idx_signal_weighted_score ON signal(weighted_score DESC);
CREATE INDEX IF NOT EXISTS idx_decision_status       ON decision(status);
CREATE INDEX IF NOT EXISTS idx_decision_commit_by    ON decision(commit_by ASC);
CREATE INDEX IF NOT EXISTS idx_pattern_reviewed      ON pattern(reviewed);
CREATE INDEX IF NOT EXISTS idx_pattern_signal_tier   ON pattern(signal_tier);
