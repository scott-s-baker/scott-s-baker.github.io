"""Stage 4 tests — parser logic only, no LLM or DB required."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from layers.interpretation import (
    _parse_direction, _parse_constraint, _parse_decision, _parse_impact,
    DirectionResult, ConstraintResult, DecisionResult, ImpactResult,
)


# ── Prompt 1: Direction ────────────────────────────────────────────────────────

def test_direction_parses_valid():
    raw = "FROM: storage as performance asset\nTO: storage as AI inference platform\nBECAUSE: Three vendors now lead with inferencing readiness as primary claim"
    r = _parse_direction(raw)
    assert r is not None
    assert r.from_state == "storage as performance asset"
    assert r.to_state == "storage as AI inference platform"
    assert "inferencing" in r.because


def test_direction_rejects_missing_field():
    raw = "FROM: storage as performance asset\nTO: storage as AI inference platform"
    assert _parse_direction(raw) is None


def test_direction_handles_unclear():
    raw = "FROM: unclear\nTO: unclear\nBECAUSE: insufficient signal clarity to determine direction"
    r = _parse_direction(raw)
    assert r is not None
    assert r.from_state == "unclear"


def test_direction_tolerates_extra_whitespace():
    raw = "  FROM:  storage on-prem  \n  TO:  hybrid cloud storage  \n  BECAUSE:  vendors shifting messaging  "
    r = _parse_direction(raw)
    assert r is not None
    assert r.from_state == "storage on-prem"


# ── Prompt 2: Constraint ───────────────────────────────────────────────────────

class _FakeAssumption:
    def __init__(self, id, statement):
        self.id = id
        self.statement = statement

def test_constraint_parses_valid():
    raw = "ASSUMPTION_ID: ASSUME-001\nBROKEN_BECAUSE: AI readiness is now primary buying criterion\nAFFECTED_AREA: narrative"
    assumptions = [_FakeAssumption("ASSUME-001", "FlashSystem competes on performance")]
    r = _parse_constraint(raw, assumptions)
    assert r is not None
    assert r.assumption_id == "ASSUME-001"
    assert r.affected_area == "narrative"
    assert r.assumption_text == "FlashSystem competes on performance"


def test_constraint_rejects_missing_field():
    raw = "ASSUMPTION_ID: ASSUME-001\nBROKEN_BECAUSE: something"
    assert _parse_constraint(raw, []) is None


def test_constraint_normalises_invalid_area():
    raw = "ASSUMPTION_ID: ASSUME-001\nBROKEN_BECAUSE: reason\nAFFECTED_AREA: marketing"
    r = _parse_constraint(raw, [_FakeAssumption("ASSUME-001", "stmt")])
    assert r.affected_area == "narrative"


# ── Prompt 3: Decision ─────────────────────────────────────────────────────────

def test_decision_parses_full_reposition():
    raw = "DECISION_TYPE: FULL_REPOSITION\nOPTION_A: Lead with AI data platform narrative\nOPTION_B: Maintain performance narrative"
    r = _parse_decision(raw)
    assert r is not None
    assert r.decision_type == "FULL_REPOSITION"
    assert r.b_trigger is None


def test_decision_parses_hold_with_trigger():
    raw = "DECISION_TYPE: HOLD_WITH_TRIGGER\nOPTION_A: Shift AI messaging now\nOPTION_B: HOLD pending trigger\nB_TRIGGER: When second enterprise deal lost citing AI readiness gap"
    r = _parse_decision(raw)
    assert r is not None
    assert r.decision_type == "HOLD_WITH_TRIGGER"
    assert r.b_trigger is not None


def test_decision_rejects_hold_without_trigger():
    # No trigger anywhere -> downgrades to FRAMING_SHIFT rather than rejecting
    raw = "DECISION_TYPE: HOLD_WITH_TRIGGER\nOPTION_A: Act now\nOPTION_B: HOLD"
    r = _parse_decision(raw)
    assert r is not None
    assert r.decision_type == "FRAMING_SHIFT"
    assert r.b_trigger is None


def test_decision_rejects_invalid_type():
    raw = "DECISION_TYPE: MAYBE_REPOSITION\nOPTION_A: A\nOPTION_B: B"
    assert _parse_decision(raw) is None


# ── Prompt 4: Impact ───────────────────────────────────────────────────────────

def test_impact_parses_valid():
    raw = "URGENCY: high\nTIME_HORIZON: short\nAFFECTED_AREA: narrative\nIMPACT: Reframe FlashSystem positioning to lead with AI inference readiness within 30 days"
    r = _parse_impact(raw)
    assert r is not None
    assert r.urgency == "high"
    assert r.time_horizon == "short"
    assert r.affected_area == "narrative"


def test_impact_rejects_invalid_urgency():
    raw = "URGENCY: critical\nTIME_HORIZON: short\nAFFECTED_AREA: narrative\nIMPACT: Act now"
    assert _parse_impact(raw) is None


def test_impact_rejects_missing_field():
    raw = "URGENCY: high\nTIME_HORIZON: short\nAFFECTED_AREA: narrative"
    assert _parse_impact(raw) is None
