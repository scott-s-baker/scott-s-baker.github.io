"""Stage 3 tests — clustering logic, no DB or Weaviate required."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from layers.clustering import _pattern_id, MIN_CLUSTER_SIZE


def test_pattern_id_deterministic():
    ids = ["sig_aaa", "sig_bbb", "sig_ccc"]
    assert _pattern_id(ids) == _pattern_id(ids)


def test_pattern_id_order_independent():
    ids = ["sig_aaa", "sig_bbb", "sig_ccc"]
    assert _pattern_id(ids) == _pattern_id(list(reversed(ids)))


def test_pattern_id_unique():
    a = _pattern_id(["sig_aaa", "sig_bbb"])
    b = _pattern_id(["sig_ccc", "sig_ddd"])
    assert a != b


def test_pattern_id_prefix():
    pid = _pattern_id(["sig_aaa"])
    assert pid.startswith("pat_")


def test_min_cluster_size():
    assert MIN_CLUSTER_SIZE >= 3


def test_noise_cluster_excluded():
    """Verify noise label (-1) logic: cluster -1 should be discarded."""
    # Each real cluster has MIN_CLUSTER_SIZE signals
    cluster_size = MIN_CLUSTER_SIZE
    topics = [-1, -1] + [0] * cluster_size + [1] * cluster_size
    signal_ids = [f"sig_{i:03d}" for i in range(len(topics))]
    clusters = {}
    for sid, t in zip(signal_ids, topics):
        if t == -1:
            continue
        clusters.setdefault(t, []).append(sid)
    assert -1 not in clusters
    assert len(clusters) == 2
    assert all(len(v) >= MIN_CLUSTER_SIZE for v in clusters.values())
