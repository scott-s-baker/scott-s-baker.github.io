"""Tests for Layer 2: Signal Quality Framework v1.1"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from datetime import datetime, timedelta, timezone
from layers.signal_quality import (
    score_signal, recency_weight, assign_tier, INDEPENDENCE_WEIGHTS,
)


def _ts(days_ago: int) -> datetime:
    return datetime.now(timezone.utc) - timedelta(days=days_ago)


def _sig(source, family, days_ago=1):
    return {"source": source, "source_family": family, "timestamp": _ts(days_ago)}


# ── Independence weights ──────────────────────────────────────────────────────

def test_field_weight_is_1():
    assert INDEPENDENCE_WEIGHTS["field"] == 1.0

def test_analyst_weight_is_1():
    assert INDEPENDENCE_WEIGHTS["analyst"] == 1.0

def test_press_weight_is_half():
    assert INDEPENDENCE_WEIGHTS["press"] == 0.5

def test_competitor_weight_is_quarter():
    assert INDEPENDENCE_WEIGHTS["competitor"] == 0.25


# ── Source-aware recency (fast curve: press/competitor) ───────────────────────

def test_press_fresh_is_1():
    assert recency_weight(3, "press") == 1.0

def test_press_7days_is_1():
    assert recency_weight(7, "press") == 1.0

def test_press_8days_is_075():
    assert recency_weight(8, "press") == 0.75

def test_press_22days_is_05():
    assert recency_weight(22, "press") == 0.5

def test_press_61days_is_archived():
    assert recency_weight(61, "press") == 0.0

def test_competitor_fast_curve():
    assert recency_weight(8, "competitor") == 0.75
    assert recency_weight(61, "competitor") == 0.0


# ── Source-aware recency (slow curve: field/analyst) ─────────────────────────

def test_field_30days_still_100():
    assert recency_weight(30, "field") == 1.0

def test_field_45days_is_075():
    assert recency_weight(45, "field") == 0.75

def test_field_90days_is_075():
    assert recency_weight(90, "field") == 0.75

def test_field_91days_is_05():
    assert recency_weight(91, "field") == 0.5

def test_field_180days_is_05():
    assert recency_weight(180, "field") == 0.5

def test_field_181days_still_025():
    """Field signals never fully archive — 0.25 floor."""
    assert recency_weight(181, "field") == 0.25

def test_analyst_slow_curve():
    assert recency_weight(60, "analyst") == 0.75
    assert recency_weight(181, "analyst") == 0.25


# ── score_signal ──────────────────────────────────────────────────────────────

def test_score_field_fresh():
    s = score_signal("field", _ts(1))
    assert s["independence_wt"] == 1.0
    assert s["recency_wt"] == 1.0
    assert s["weighted_score"] == 1.0

def test_score_press_week_old():
    s = score_signal("press", _ts(10))
    assert s["independence_wt"] == 0.5
    assert s["recency_wt"] == 0.75
    assert s["weighted_score"] == round(0.5 * 0.75, 3)

def test_score_field_45days():
    """Field signal at 45 days still scores 0.75 (slow decay curve)."""
    s = score_signal("field", _ts(45))
    assert s["weighted_score"] == 0.75

def test_score_press_archived():
    s = score_signal("press", _ts(65))
    assert s["weighted_score"] == 0.0


# ── assign_tier ───────────────────────────────────────────────────────────────

def test_single_field_below_threshold():
    """Single field signal = 1.0 weighted — below EMERGING threshold of 2.0."""
    r = assign_tier([_sig("field", "peerspot-ibm")])
    assert r.tier is None
    assert r.weighted_count == 1.0

def test_two_field_families_emerging():
    """Two field signals from different families = 2.0 weighted → EMERGING."""
    r = assign_tier([_sig("field", "peerspot-ibm"), _sig("field", "peerspot-dell")])
    assert r.tier == "EMERGING"

def test_field_plus_analyst_confirmed():
    """2 field + 1 analyst = 3.0 weighted, 2 categories → CONFIRMED."""
    sigs = [
        _sig("field", "peerspot-ibm"),
        _sig("field", "peerspot-dell"),
        _sig("analyst", "dcig.com"),
    ]
    r = assign_tier(sigs)
    assert r.tier == "CONFIRMED"
    assert r.source_categories >= 2

def test_old_field_signal_still_counts():
    """Field signal at 45 days (slow decay = 0.75) still contributes to score.
    
    0.75 + 0.75 + 1.0 = 2.5 weighted, 2 categories → EMERGING (< 3.0 for CONFIRMED).
    The key point is that old field signals are NOT archived (unlike press at 65d).
    """
    sigs = [
        _sig("field", "peerspot-ibm", days_ago=45),
        _sig("field", "peerspot-dell", days_ago=45),
        _sig("analyst", "dcig.com", days_ago=5),
    ]
    r = assign_tier(sigs)
    # 2.5 weighted = EMERGING (not None) — confirms slow decay keeps signal alive
    assert r.tier == "EMERGING"
    assert r.weighted_count == 2.5

def test_old_press_archived():
    """Press signal > 60 days = 0.0 weight, excluded from tier."""
    r = assign_tier([_sig("press", "blocksandfiles.com", days_ago=65)])
    assert r.tier is None

def test_same_source_dedup():
    """Multiple signals from same source_family count as one (dedup by family)."""
    sigs = [
        _sig("field", "peerspot-ibm", days_ago=1),
        _sig("field", "peerspot-ibm", days_ago=2),
        _sig("field", "peerspot-ibm", days_ago=3),
    ]
    r = assign_tier(sigs)
    # After dedup: 1 signal, weighted_count = 1.0 → None (below threshold)
    assert r.tier is None
    assert r.source_categories == 1

def test_established_requires_weight_and_age():
    """ESTABLISHED: >= 5.0 weighted, 3+ categories, max_age >= 30 days."""
    sigs = [
        _sig("field",   "peerspot-ibm",    days_ago=1),
        _sig("field",   "peerspot-dell",   days_ago=1),
        _sig("field",   "peerspot-pure",   days_ago=1),
        _sig("field",   "peerspot-netapp", days_ago=1),
        _sig("analyst", "dcig.com",        days_ago=1),
        _sig("press",   "blocksandfiles",   days_ago=35),  # provides max_age >= 30
    ]
    r = assign_tier(sigs)
    # 4*1.0 + 1*1.0 + 0.25 = 5.25, 3 categories, max_age=35 → ESTABLISHED
    assert r.tier == "ESTABLISHED"
    assert r.source_categories >= 3
