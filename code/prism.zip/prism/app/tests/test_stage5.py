"""Stage 5 tests — SLA logic, tier mapping, outcome validation. No DB needed."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from datetime import date, timedelta
from layers.stage5 import (
    SLA_DAYS, DECISION_MODEL_MAP, VALID_OUTCOMES,
    WARNING_DAYS_BEFORE,
)


# ── SLA config ────────────────────────────────────────────────────────────────

def test_sla_days_defined():
    assert SLA_DAYS["high"] == 5
    assert SLA_DAYS["medium"] == 14
    assert SLA_DAYS["low"] == 30


def test_sla_high_shorter_than_low():
    assert SLA_DAYS["high"] < SLA_DAYS["medium"] < SLA_DAYS["low"]


def test_warning_days_positive():
    assert WARNING_DAYS_BEFORE >= 1


# ── Decision model mapping ─────────────────────────────────────────────────────

def test_all_tier_urgency_combinations_mapped():
    tiers = ["EMERGING", "CONFIRMED", "ESTABLISHED"]
    urgencies = ["low", "medium", "high"]
    for t in tiers:
        for u in urgencies:
            assert (t, u) in DECISION_MODEL_MAP, f"missing ({t}, {u})"


def test_emerging_uses_axis_shift():
    assert DECISION_MODEL_MAP[("EMERGING", "low")] == "axis_shift"
    assert DECISION_MODEL_MAP[("EMERGING", "high")] == "axis_shift"


def test_confirmed_escalates_model():
    assert DECISION_MODEL_MAP[("CONFIRMED", "medium")] == "narrative_drift"


def test_established_uses_entry_validity():
    assert DECISION_MODEL_MAP[("ESTABLISHED", "high")] == "entry_validity"


# ── Outcome tracking ───────────────────────────────────────────────────────────

def test_valid_outcomes_set():
    assert VALID_OUTCOMES == {"accurate", "inaccurate", "inconclusive"}


def test_outcome_review_periods():
    # Only 30, 60, 90 are valid
    valid = {30, 60, 90}
    assert 30 in valid and 60 in valid and 90 in valid
    assert 45 not in valid


# ── SLA date arithmetic ────────────────────────────────────────────────────────

def test_overdue_detection():
    today = date.today()
    overdue = today - timedelta(days=1)
    upcoming = today + timedelta(days=10)
    assert (overdue - today).days < 0
    assert (upcoming - today).days > 0


def test_warning_window():
    today = date.today()
    within_warning = today + timedelta(days=WARNING_DAYS_BEFORE - 1)
    outside_warning = today + timedelta(days=WARNING_DAYS_BEFORE + 1)
    days_remaining_warn = (within_warning - today).days
    days_remaining_out = (outside_warning - today).days
    assert 0 <= days_remaining_warn <= WARNING_DAYS_BEFORE
    assert days_remaining_out > WARNING_DAYS_BEFORE


def test_expiry_threshold():
    today = date.today()
    expired = today - timedelta(days=91)
    not_expired = today - timedelta(days=89)
    assert (expired - today).days < -90
    assert (not_expired - today).days > -90


# ── Model suspension threshold ─────────────────────────────────────────────────

def test_suspension_threshold_is_40_percent():
    # Doc: suspend model if >40% inaccurate over 90 days
    inaccurate = 5
    total = 10
    rate = inaccurate / total
    assert rate > 0.40  # would trigger suspension

    inaccurate2 = 3
    rate2 = inaccurate2 / total
    assert rate2 <= 0.40  # would not trigger
