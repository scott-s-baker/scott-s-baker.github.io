"""Stage 2 ingestion tests — tagging + HTML block extraction, no network/DB."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ingest.tagging import extract_entities, extract_tags
from ingest.competitor import _extract_blocks


def test_entities_detect_competitors():
    txt = "Dell PowerStore now ships with new PowerMax integration."
    ents = extract_entities(txt)
    assert "dell" in ents
    assert "pure" not in ents


def test_entities_multiple():
    txt = "Pure Storage FlashArray vs NetApp ONTAP in AI workloads."
    ents = extract_entities(txt)
    assert set(["pure", "netapp"]).issubset(set(ents))


def test_tags_ai_and_governance():
    txt = "New inferencing-ready array meets EU sovereignty and GDPR compliance needs."
    tags = extract_tags(txt)
    assert "AI" in tags
    assert "governance" in tags


def test_tags_cyber_resilience():
    txt = "Immutable snapshots and ransomware recovery with air gap protection."
    assert "cyber_resilience" in extract_tags(txt)


def test_extract_blocks_filters_short():
    html = """<main><h1>Operational AI storage for the enterprise</h1>
              <nav>Home</nav>
              <p class='hero'>Built to drive inferencing at scale across hybrid cloud.</p></main>"""
    blocks = _extract_blocks(html, "main h1, main p.hero, nav")
    # nav 'Home' (4 chars) dropped; h1 and hero kept
    assert len(blocks) == 2
    assert any("Operational AI" in b for b in blocks)
