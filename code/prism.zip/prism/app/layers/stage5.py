"""Stage 5: Decision model engine.

Three responsibilities:
1. Decision model selection — which model fires for a given pattern tier/type
2. SLA enforcement — auto-escalate OPEN decisions past commit_by to DEFERRED,
   expire stale decisions, surface accountability gaps
3. Outcome tracking — record 30/60/90-day review results so the system
   can measure whether its decisions were accurate (the falsifiability
   requirement the doc makes mandatory in V1)

The doc's key rule: DEFERRED is not neutral. An un-actioned decision past
commit_by is a visible governance failure, not a quiet skip.
"""
from __future__ import annotations
import logging
import os
from datetime import date, datetime, timezone, timedelta
from dataclasses import dataclass

log = logging.getLogger("prism.layers.stage5")


from db.pool import connection as _pg


# ── Decision model selection ───────────────────────────────────────────────────

# Maps (signal_tier, urgency) → recommended decision model
# The doc defines three models: narrative_drift, entry_validity, axis_shift
# We only have axis_shift built (Stage 4). This table prepares for the others.
DECISION_MODEL_MAP = {
    ("EMERGING",    "low"):    "axis_shift",
    ("EMERGING",    "medium"): "axis_shift",
    ("EMERGING",    "high"):   "axis_shift",
    ("CONFIRMED",   "low"):    "axis_shift",
    ("CONFIRMED",   "medium"): "narrative_drift",   # will be built in a future stage
    ("CONFIRMED",   "high"):   "narrative_drift",
    ("ESTABLISHED", "low"):    "entry_validity",     # will be built in a future stage
    ("ESTABLISHED", "medium"): "entry_validity",
    ("ESTABLISHED", "high"):   "entry_validity",
}

# SLA days by urgency (doc: 48h ack, 5-day decision for high urgency)
SLA_DAYS = {"high": 5, "medium": 14, "low": 30}

# How many days before commit_by to send a warning (not yet built into delivery)
WARNING_DAYS_BEFORE = 2


@dataclass
class SLAStatus:
    decision_id: str
    signal: str
    decision_type: str
    urgency: str
    commit_by: date
    days_remaining: int
    is_overdue: bool
    is_warning: bool         # within WARNING_DAYS_BEFORE of commit_by
    current_status: str
    decision_owner: str


# ── SLA enforcement ────────────────────────────────────────────────────────────

def run_sla_enforcement() -> dict:
    """
    Scan all OPEN decisions:
    - Past commit_by → mark DEFERRED (visible governance failure)
    - Approaching commit_by → flag as warning
    - Expired (>90 days past commit_by, still OPEN/DEFERRED) → mark EXPIRED

    Returns summary of changes made.
    """
    today = date.today()
    deferred_count = expired_count = warned_count = 0

    with _pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT id, urgency, commit_by, status, created_at
                   FROM decision
                   WHERE status IN ('OPEN', 'DEFERRED')
                   ORDER BY commit_by ASC;"""
            )
            rows = cur.fetchall()

        for dec_id, urgency, commit_by, status, created_at in rows:
            if isinstance(commit_by, datetime):
                commit_by = commit_by.date()
            days_remaining = (commit_by - today).days

            # Expired: >90 days overdue and still not actioned
            if days_remaining < -90 and status in ("OPEN", "DEFERRED"):
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE decision SET status='EXPIRED' WHERE id=%s;",
                        (dec_id,)
                    )
                expired_count += 1
                log.info("EXPIRED decision %s (commit_by %s)", dec_id, commit_by)

            # Overdue: past commit_by, still OPEN
            elif days_remaining < 0 and status == "OPEN":
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE decision SET status='DEFERRED' WHERE id=%s;",
                        (dec_id,)
                    )
                deferred_count += 1
                log.warning(
                    "DEFERRED decision %s — %d days overdue (owner: PMM Lead)",
                    dec_id, abs(days_remaining)
                )

            # Warning: approaching deadline
            elif 0 <= days_remaining <= WARNING_DAYS_BEFORE and status == "OPEN":
                warned_count += 1
                log.info(
                    "WARNING decision %s — %d days until commit_by",
                    dec_id, days_remaining
                )

        conn.commit()

    log.info(
        "SLA enforcement: %d deferred, %d expired, %d warnings",
        deferred_count, expired_count, warned_count
    )
    return {
        "deferred": deferred_count,
        "expired": expired_count,
        "warnings": warned_count,
        "run_at": datetime.now(timezone.utc).isoformat(),
    }


def get_sla_status() -> list[dict]:
    """Full SLA status report for all non-expired decisions."""
    today = date.today()
    with _pg() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT id, signal, decision_type, urgency, commit_by,
                      status, decision_owner, decided_at
               FROM decision
               WHERE status != 'EXPIRED'
               ORDER BY commit_by ASC;"""
        )
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()

    results = []
    for row in rows:
        d = dict(zip(cols, row))
        commit_by = d["commit_by"]
        if isinstance(commit_by, datetime):
            commit_by = commit_by.date()
        days_remaining = (commit_by - today).days
        decided_at = d.get("decided_at")
        results.append({
            "decision_id":   d["id"],
            "signal":        d["signal"][:80] if d["signal"] else "",
            "decision_type": d["decision_type"],
            "urgency":       d["urgency"],
            "commit_by":     commit_by.isoformat(),
            "days_remaining":days_remaining,
            "is_overdue":    days_remaining < 0,
            "is_warning":    0 <= days_remaining <= WARNING_DAYS_BEFORE,
            "status":        d["status"],
            "decision_owner":d["decision_owner"],
            "decided_at":    decided_at.isoformat() if decided_at else None,
        })
    return results


# ── Tier upgrade logic ─────────────────────────────────────────────────────────

def run_tier_upgrades() -> dict:
    """
    Re-evaluate pattern signal tiers based on current signal volume.
    Patterns that have accumulated enough weighted signal to move from
    EMERGING → CONFIRMED or CONFIRMED → ESTABLISHED get upgraded,
    and their linked decisions get urgency bumped accordingly.
    """
    import json
    from layers.signal_quality import assign_tier

    upgraded = 0
    with _pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT p.id, p.signal_ids, p.signal_tier
                   FROM pattern p
                   WHERE p.reviewed = true;"""
            )
            patterns = cur.fetchall()

        for pat_id, signal_ids_raw, current_tier in patterns:
            if isinstance(signal_ids_raw, str):
                signal_ids = json.loads(signal_ids_raw)
            else:
                signal_ids = signal_ids_raw or []

            if not signal_ids:
                continue

            # Fetch signals for this pattern
            with conn.cursor() as cur:
                cur.execute(
                    """SELECT source, source_family, timestamp, weighted_score
                       FROM signal WHERE id = ANY(%s);""",
                    (signal_ids,)
                )
                sigs = cur.fetchall()

            if not sigs:
                continue

            # Build signal list for Layer 2 tier assignment
            sig_list = [
                {
                    "source": s[0],
                    "source_family": s[1],
                    "timestamp": s[2],
                    "weighted_score": float(s[3] or 0),
                }
                for s in sigs
            ]

            tier_result = assign_tier(sig_list)
            new_tier = tier_result.tier or "EMERGING"

            if new_tier != current_tier:
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE pattern SET signal_tier=%s WHERE id=%s;",
                        (new_tier, pat_id)
                    )
                log.info(
                    "tier upgrade: pattern %s %s → %s",
                    pat_id, current_tier, new_tier
                )

                # Bump urgency on linked decisions if tier upgraded
                if new_tier in ("CONFIRMED", "ESTABLISHED"):
                    new_urgency = "medium" if new_tier == "CONFIRMED" else "high"
                    new_sla = SLA_DAYS[new_urgency]
                    new_commit = date.today() + timedelta(days=new_sla)
                    with conn.cursor() as cur:
                        cur.execute(
                            """UPDATE decision
                               SET urgency=%s, commit_by=%s
                               WHERE id LIKE %s AND status='OPEN';""",
                            (new_urgency, new_commit, f"%{pat_id[:20]}%")
                        )
                upgraded += 1

        conn.commit()

    return {"patterns_evaluated": len(patterns), "tiers_upgraded": upgraded}


# ── Outcome tracking ───────────────────────────────────────────────────────────

VALID_OUTCOMES = {"accurate", "inaccurate", "inconclusive"}


def record_outcome(
    decision_id: str,
    review_period: int,    # 30, 60, or 90
    outcome: str,
    notes: str = "",
) -> dict:
    """
    Record a 30/60/90-day outcome review for a decision.
    This is the falsifiability mechanism — without it the system
    cannot know if its decisions were correct.
    """
    if outcome not in VALID_OUTCOMES:
        return {"error": f"outcome must be one of {VALID_OUTCOMES}"}
    if review_period not in (30, 60, 90):
        return {"error": "review_period must be 30, 60, or 90"}

    col = f"review_{review_period}d"
    with _pg() as conn, conn.cursor() as cur:
        cur.execute(
            f"UPDATE decision SET {col}=%s WHERE id=%s RETURNING id;",
            (outcome, decision_id)
        )
        found = cur.fetchone() is not None
        if found and notes:
            cur.execute(
                "UPDATE decision SET notes=%s WHERE id=%s;",
                (notes, decision_id)
            )
        conn.commit()

    return {
        "decision_id": decision_id,
        "review_period": review_period,
        "outcome": outcome,
        "recorded": found,
    }


def get_outcome_summary() -> dict:
    """
    Aggregate outcome accuracy across all reviewed decisions.
    The doc requires this to suspend models with >40% inaccurate over 90 days.
    """
    with _pg() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT
                 COUNT(*) FILTER (WHERE review_30d IS NOT NULL) as reviewed_30d,
                 COUNT(*) FILTER (WHERE review_30d = 'accurate') as accurate_30d,
                 COUNT(*) FILTER (WHERE review_30d = 'inaccurate') as inaccurate_30d,
                 COUNT(*) FILTER (WHERE review_60d IS NOT NULL) as reviewed_60d,
                 COUNT(*) FILTER (WHERE review_60d = 'accurate') as accurate_60d,
                 COUNT(*) FILTER (WHERE review_60d = 'inaccurate') as inaccurate_60d,
                 COUNT(*) FILTER (WHERE review_90d IS NOT NULL) as reviewed_90d,
                 COUNT(*) FILTER (WHERE review_90d = 'accurate') as accurate_90d,
                 COUNT(*) FILTER (WHERE review_90d = 'inaccurate') as inaccurate_90d,
                 COUNT(*) as total_decisions
               FROM decision;"""
        )
        row = cur.fetchone()
        cols = [d[0] for d in cur.description]
        stats = dict(zip(cols, row))

    # Compute inaccuracy rate for 90-day window (doc suspension threshold: >40%)
    if stats["reviewed_90d"] and stats["reviewed_90d"] > 0:
        inaccuracy_rate = stats["inaccurate_90d"] / stats["reviewed_90d"]
        stats["inaccuracy_rate_90d"] = round(inaccuracy_rate, 3)
        stats["model_suspension_risk"] = inaccuracy_rate > 0.40
    else:
        stats["inaccuracy_rate_90d"] = None
        stats["model_suspension_risk"] = False

    return stats


# ── Full Stage 5 run ───────────────────────────────────────────────────────────

def run_stage5() -> dict:
    """Run all Stage 5 checks: SLA enforcement + tier upgrades."""
    sla = run_sla_enforcement()
    tiers = run_tier_upgrades()
    outcomes = get_outcome_summary()
    return {
        "sla": sla,
        "tier_upgrades": tiers,
        "outcome_summary": outcomes,
    }
