"""Layer 2: Signal Quality Framework (design doc).

Pure rules — no model self-assessment. Implements independence scoring,
recency weighting, same-source dedup, and tier assignment exactly as the
doc specifies. This layer prevents contaminated signal reaching the
interpretation and decision layers.

v1.1 changes:
- Source-aware recency decay: field/analyst signals decay slowly (reviews
  and analyst reports are valid for months, not days). Press/competitor
  signals decay fast (news is perishable).
- recency_weight() now takes source as optional arg.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone

# Source independence weights (doc §Layer 2 table)
INDEPENDENCE_WEIGHTS = {
    "analyst":    1.0,   # independent, methodologically grounded
    "sales":      1.0,   # unfiltered buyer signal
    "field":      1.0,   # outcome-validated, direct market contact
    "slack":      0.75,  # reactive; confirmation not discovery
    "internal":   0.75,
    "press":      0.5,   # often competitor PR; corroborating only
    "competitor": 0.25,  # adversarial by design; discounted not excluded
}

# Recency decay curves by source type.
# Field/analyst: slower decay — a buyer review from 6 months ago is still signal.
# Press/competitor: fast decay — yesterday's news is noise by next month.
_DECAY_CURVES = {
    "fast": [
        (7,   1.0),
        (21,  0.75),
        (60,  0.5),
        (float("inf"), 0.0),  # archived
    ],
    "slow": [
        (30,  1.0),
        (90,  0.75),
        (180, 0.5),
        (float("inf"), 0.25),  # never fully archived — field signal stays relevant
    ],
}

_SOURCE_CURVE = {
    "analyst":    "slow",
    "field":      "slow",
    "sales":      "slow",
    "internal":   "slow",
    "slack":      "fast",
    "press":      "fast",
    "competitor": "fast",
}


def recency_weight(age_days: float, source: str = "press") -> float:
    """Source-aware recency weighting.
    
    Field/analyst: slow curve — valid for 6 months.
    Press/competitor: fast curve — stale after 60 days.
    """
    curve_key = _SOURCE_CURVE.get(source, "fast")
    for threshold, weight in _DECAY_CURVES[curve_key]:
        if age_days <= threshold:
            return weight
    return 0.0


def score_signal(source: str, timestamp: datetime, *, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    age = (now - timestamp).total_seconds() / 86400
    iw = INDEPENDENCE_WEIGHTS.get(source, 0.5)
    rw = recency_weight(age, source)
    return {"independence_wt": iw, "recency_wt": rw, "weighted_score": round(iw * rw, 3)}


@dataclass
class TierResult:
    tier: str | None          # EMERGING | CONFIRMED | ESTABLISHED | None
    weighted_count: float
    source_categories: int
    action: str


def assign_tier(signals: list[dict], *, now: datetime | None = None) -> TierResult:
    """Doc §Signal Tier System.

    Dedup rule: multiple posts from the same source_family count as ONE signal
    regardless of volume (same-origin does not create independence).
    
    v1.1: recency is recalculated at evaluation time, not read from stored score.
    """
    now = now or datetime.now(timezone.utc)

    # Same-source dedup: keep the single highest-weighted signal per source_family.
    # Recalculate recency at evaluation time using current timestamp.
    by_family: dict[str, dict] = {}
    for s in signals:
        # Recalculate fresh — don't trust stored weighted_score
        scored = score_signal(s["source"], s["timestamp"], now=now)
        if scored["recency_wt"] == 0.0:
            continue  # archived, excluded from tier
        fam = s["source_family"]
        if fam not in by_family or scored["weighted_score"] > by_family[fam]["_ws"]:
            by_family[fam] = {**s, "_ws": scored["weighted_score"], "_iw": scored["independence_wt"]}

    deduped = list(by_family.values())
    weighted_count = sum(d["_ws"] for d in deduped)
    categories = len({d["source"] for d in deduped})
    max_age = max(
        ((now - (d["timestamp"].replace(tzinfo=timezone.utc) if d["timestamp"].tzinfo is None else d["timestamp"]))
         .total_seconds() / 86400) for d in deduped
    ) if deduped else 0

    # ESTABLISHED: >=5 weighted, 3+ categories, 30+ days sustained
    if weighted_count >= 5 and categories >= 3 and max_age >= 30:
        return TierResult("ESTABLISHED", weighted_count, categories, "Escalate urgency to HIGH.")
    # CONFIRMED: >=3 weighted, 2+ categories
    if weighted_count >= 3 and categories >= 2:
        return TierResult("CONFIRMED", weighted_count, categories, "Trigger decision model.")
    # EMERGING: >=2 weighted, 1+ category
    if weighted_count >= 2 and categories >= 1:
        return TierResult("EMERGING", weighted_count, categories, "Monitor. Do not trigger decision.")
    return TierResult(None, weighted_count, categories, "Below threshold. No tier.")
