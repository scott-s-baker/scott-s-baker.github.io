"""Positioning assumption config loader (design doc: 'most fragile component').

Reads config/positioning_assumptions.yaml. Assumptions not reviewed in
>90 days are flagged STALE and EXCLUDED from decision logic — enforced here,
not left to the caller. A STALE config silently producing wrong decisions
is the failure mode the doc explicitly warns about.
"""
from __future__ import annotations
import logging
import os
from datetime import date, timedelta
from pathlib import Path
from typing import NamedTuple

import yaml

log = logging.getLogger("prism.layers.assumptions")

STALE_DAYS = int(os.getenv("CONFIG_STALE_DAYS", "90"))
CONFIG_PATH = Path(os.getenv("PRISM_CONFIG_PATH", "/app/config/positioning_assumptions.yaml"))


class Assumption(NamedTuple):
    id: str
    statement: str
    affected_area: str
    date_encoded: date
    last_reviewed: date
    owner: str
    stale: bool


def load_assumptions(include_stale: bool = False) -> list[Assumption]:
    """Load assumptions. STALE ones excluded by default — pass include_stale=True to inspect."""
    if not CONFIG_PATH.exists():
        log.warning("assumptions config not found at %s", CONFIG_PATH)
        return []

    raw = yaml.safe_load(CONFIG_PATH.read_text())
    today = date.today()
    cutoff = today - timedelta(days=STALE_DAYS)

    results = []
    for a in raw.get("assumptions", []):
        last_reviewed = a.get("last_reviewed")
        if isinstance(last_reviewed, str):
            last_reviewed = date.fromisoformat(last_reviewed)
        stale = last_reviewed < cutoff if last_reviewed else True

        if stale:
            log.warning(
                "STALE assumption %s (last reviewed %s) — EXCLUDED from decision logic",
                a["id"], last_reviewed
            )
            if not include_stale:
                continue

        results.append(Assumption(
            id=a["id"],
            statement=a["statement"],
            affected_area=a.get("affected_area", "narrative"),
            date_encoded=date.fromisoformat(str(a["date_encoded"])),
            last_reviewed=last_reviewed,
            owner=a.get("owner", ""),
            stale=stale,
        ))

    meta = raw.get("meta", {})
    next_review = meta.get("next_quarterly_review_due")
    if next_review:
        if isinstance(next_review, str):
            next_review = date.fromisoformat(next_review)
        if today > next_review:
            log.error(
                "QUARTERLY REVIEW OVERDUE (due %s) — review /app/config/positioning_assumptions.yaml",
                next_review
            )

    return results


def assumptions_as_text(assumptions: list[Assumption]) -> str:
    """Format assumptions as numbered text block for LLM prompts."""
    if not assumptions:
        return "(no active assumptions — config may be stale or missing)"
    return "\n".join(
        f"{i+1}. [{a.id}] {a.statement}"
        for i, a in enumerate(assumptions)
    )
