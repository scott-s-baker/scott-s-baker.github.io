"""Layer 3b: Clustering — UMAP → HDBSCAN → BERTopic → Pattern objects.

Pulls embeddings from Weaviate, reduces dimensionality with UMAP, clusters
with HDBSCAN, extracts topic labels with BERTopic, then writes Pattern objects
to Postgres.

Key design decisions matching the doc:
- Manual review gate: patterns created in the first 30 days have reviewed=False
  and are excluded from Layer 4 interpretation until a human marks them reviewed.
  This is the calibration period the doc mandates.
- Minimum cluster size: 5 signals (raised from 3 at >500 signal volume).
- Each cluster becomes one Pattern with the BERTopic label as summary.
- signal_ids and source_count stored on the Pattern for Layer 4 to use.

v1.1 changes:
- Relevance filter: only domain-relevant signals enter UMAP. Non-storage signals
  are stored but don't pollute cluster space.
- MIN_CLUSTER_SIZE raised to 5 — reduces noise clusters at current volume.
- Weaviate iterator replaced with aggregate count check to detect under-reporting.
- _fetch_vectors_from_weaviate returns tags/entities for relevance filtering.
"""
from __future__ import annotations
import logging
import os
import json
import hashlib
from datetime import datetime, timezone

import numpy as np

log = logging.getLogger("prism.layers.clustering")

MANUAL_REVIEW_GATE_DAYS = 30
MIN_CLUSTER_SIZE = 5   # raised from 3 — at 500+ signals noise reduction needed

# Tags and entity keywords that mark a signal as domain-relevant.
# Signals with NONE of these are filtered out before clustering.
RELEVANT_TAGS = {
    "AI", "cyber_resilience", "governance", "hybrid", "pricing", "performance",
}
RELEVANT_ENTITIES = {
    "dell", "pure", "netapp", "hpe", "huawei", "hitachi", "ibm",
}
RELEVANT_KEYWORDS = {
    "storage", "flash", "nvme", "array", "ransomware", "cyber", "resilience",
    "agentic", "ai", "inference", "sovereignty", "cloud", "backup",
    "data protection", "replication", "snapshot", "dedup", "compression",
    "flashsystem", "flasharray", "oceanstor", "powerstore", "alletra",
    "ontap", "safeguarded", "immutable", "everpure", "purity", "deepreduce",
}


from db.pool import connection as _pg


def _in_calibration_period() -> bool:
    """True if we're within MANUAL_REVIEW_GATE_DAYS of first signal."""
    with _pg() as conn, conn.cursor() as cur:
        cur.execute("SELECT MIN(created_at) FROM signal;")
        row = cur.fetchone()
        if not row or not row[0]:
            return True
        first = row[0]
        if first.tzinfo is None:
            first = first.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - first).days
        return age < MANUAL_REVIEW_GATE_DAYS


def _is_relevant(content: str, tags: list, entities: list) -> bool:
    """Return True if a signal is domain-relevant for clustering."""
    if any(t in RELEVANT_TAGS for t in (tags or [])):
        return True
    if any(e in RELEVANT_ENTITIES for e in (entities or [])):
        return True
    lo = content.lower()
    if any(kw in lo for kw in RELEVANT_KEYWORDS):
        return True
    return False


def _fetch_vectors_from_weaviate() -> tuple[list[str], list[str], np.ndarray]:
    """Returns (signal_ids, contents, vectors) — relevant signals only."""
    import weaviate
    url = os.getenv("WEAVIATE_URL", "http://weaviate:8080")
    host = url.replace("http://", "").replace("https://", "").split(":")[0]
    port = int(url.split(":")[-1]) if ":" in url.split("//")[-1] else 8080

    client = weaviate.connect_to_local(host=host, port=port)
    try:
        collection = client.collections.get("PrismSignal")

        # Check aggregate count first — iterator can under-report on older Weaviate versions
        try:
            agg = collection.aggregate.over_all(total_count=True)
            total = agg.total_count
        except Exception:
            total = 0

        if total == 0:
            return [], [], np.array([])

        objects = list(collection.iterator(
            return_properties=["signal_id", "content", "tags", "entities"],
            include_vector=True,
        ))

        # If iterator returns far fewer than aggregate, warn and use what we have
        if len(objects) < total * 0.8:
            log.warning(
                "Weaviate iterator returned %d objects but aggregate shows %d — "
                "consider deleting and re-embedding PrismSignal collection",
                len(objects), total
            )

        filtered_ids, filtered_contents, filtered_vecs = [], [], []
        skipped = 0
        for o in objects:
            content  = o.properties.get("content", "")
            tags     = o.properties.get("tags") or []
            entities = o.properties.get("entities") or []
            if not isinstance(tags, list):     tags = []
            if not isinstance(entities, list): entities = []

            if _is_relevant(content, tags, entities):
                filtered_ids.append(o.properties["signal_id"])
                filtered_contents.append(content)
                filtered_vecs.append(o.vector["default"])
            else:
                skipped += 1

        log.info(
            "relevance filter: %d relevant / %d total (%d skipped)",
            len(filtered_ids), len(filtered_ids) + skipped, skipped
        )
        if not filtered_ids:
            return [], [], np.array([])
        return filtered_ids, filtered_contents, np.array(filtered_vecs)
    finally:
        client.close()


def _pattern_id(signal_ids: list[str]) -> str:
    h = hashlib.sha256("|".join(sorted(signal_ids)).encode()).hexdigest()
    return f"pat_{h[:24]}"


def run_clustering() -> dict:
    """
    Full clustering pipeline: fetch → UMAP → HDBSCAN → BERTopic → write Patterns.
    Returns summary dict.
    """
    from umap import UMAP
    from hdbscan import HDBSCAN
    from bertopic import BERTopic
    from sklearn.feature_extraction.text import CountVectorizer

    signal_ids, contents, vectors = _fetch_vectors_from_weaviate()

    if len(signal_ids) < MIN_CLUSTER_SIZE * 2:
        log.info("clustering: not enough vectors (%d), need %d", len(signal_ids), MIN_CLUSTER_SIZE * 2)
        return {"status": "insufficient_data", "signal_count": len(signal_ids),
                "min_required": MIN_CLUSTER_SIZE * 2}

    log.info("clustering %d relevant signals", len(signal_ids))

    # UMAP: reduce to 5 dims for clustering (doc recommendation)
    n_neighbors = min(15, len(signal_ids) - 1)
    umap_model = UMAP(
        n_components=5,
        n_neighbors=n_neighbors,
        min_dist=0.0,
        metric="cosine",
        random_state=42,
    )

    # HDBSCAN — min_cluster_size scales with corpus size
    min_cluster = min(MIN_CLUSTER_SIZE, max(3, len(signal_ids) // 20))
    hdbscan_model = HDBSCAN(
        min_cluster_size=min_cluster,
        min_samples=1,
        metric="euclidean",
        cluster_selection_method="eom",
        prediction_data=True,
    )

    # BERTopic wiring — use our UMAP + HDBSCAN, CPU vectorizer
    vectorizer = CountVectorizer(stop_words="english", min_df=1, ngram_range=(1, 2))
    topic_model = BERTopic(
        umap_model=umap_model,
        hdbscan_model=hdbscan_model,
        vectorizer_model=vectorizer,
        verbose=False,
        calculate_probabilities=False,
    )

    topics, _ = topic_model.fit_transform(contents, embeddings=vectors)

    # Get topic info
    topic_info = topic_model.get_topic_info()
    in_calibration = _in_calibration_period()

    patterns_written = 0
    patterns_skipped = 0

    with _pg() as conn:
        for _, row in topic_info.iterrows():
            topic_id = row["Topic"]
            if topic_id == -1:
                continue  # noise cluster — discard

            # Signal IDs in this cluster
            cluster_sids = [
                signal_ids[i] for i, t in enumerate(topics) if t == topic_id
            ]
            if len(cluster_sids) < MIN_CLUSTER_SIZE:
                patterns_skipped += 1
                continue

            # BERTopic label words → summary string
            topic_words = topic_model.get_topic(topic_id)
            if topic_words:
                label = ", ".join(w for w, _ in topic_words[:5])
            else:
                label = f"cluster_{topic_id}"

            summary = f"Market signal cluster: {label}"

            # Source count (unique source categories in cluster)
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(DISTINCT source) FROM signal WHERE id = ANY(%s)",
                    (cluster_sids,)
                )
                source_count = cur.fetchone()[0]

            pid = _pattern_id(cluster_sids)

            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO pattern
                         (id, signal_ids, summary, direction, signal_tier,
                          source_count, reviewed)
                       VALUES (%s, %s, %s, %s, %s, %s, %s)
                       ON CONFLICT (id) DO NOTHING
                       RETURNING id;""",
                    (
                        pid,
                        json.dumps(cluster_sids),
                        summary,
                        label,
                        "EMERGING",
                        source_count,
                        not in_calibration,
                    )
                )
                if cur.fetchone():
                    patterns_written += 1
                else:
                    patterns_skipped += 1

        conn.commit()

    log.info("clustering done: %d patterns written, %d skipped",
             patterns_written, patterns_skipped)
    return {
        "status": "ok",
        "signals_clustered": len(signal_ids),
        "patterns_written": patterns_written,
        "patterns_skipped": patterns_skipped,
        "in_calibration": in_calibration,
        "reviewed_gate": in_calibration,
    }


def get_patterns(reviewed_only: bool = False) -> list[dict]:
    """Fetch patterns with signal samples for human review.

    Returns signal_samples (up to 5 content snippets) and source_breakdown
    so reviewers can judge relevance without guessing from keywords alone.
    """
    with _pg() as conn:
        with conn.cursor() as cur:
            if reviewed_only:
                cur.execute(
                    """SELECT id, summary, direction, signal_tier, source_count,
                              reviewed, created_at, signal_ids
                       FROM pattern WHERE reviewed = true
                       ORDER BY created_at DESC;"""
                )
            else:
                cur.execute(
                    """SELECT id, summary, direction, signal_tier, source_count,
                              reviewed, created_at, signal_ids
                       FROM pattern ORDER BY created_at DESC;"""
                )
            cols = [d[0] for d in cur.description]
            base_rows = cur.fetchall()

        # Parse pattern rows first, collecting every signal ID we need,
        # then fetch all sample candidates in ONE query instead of one
        # query per pattern (N+1 on the busiest GUI endpoint).
        rows = []
        wanted_sids: set[str] = set()
        for row in base_rows:
            d = dict(zip(cols, row))
            if isinstance(d.get("signal_ids"), str):
                d["signal_ids"] = json.loads(d["signal_ids"])
            wanted_sids.update(d["signal_ids"][:20])
            rows.append(d)

        sig_map: dict[str, tuple] = {}
        if wanted_sids:
            with conn.cursor() as cur:
                cur.execute(
                    """SELECT id, source, source_family, content, weighted_score
                       FROM signal WHERE id = ANY(%s::text[]);""",
                    (list(wanted_sids),)
                )
                for sid, source, family, content, ws in cur.fetchall():
                    sig_map[sid] = (source, family, content, float(ws))

        for d in rows:
            # Same semantics as before: top 5 by weighted_score from the
            # first 20 signal IDs of the pattern
            picks = sorted(
                (sig_map[s] for s in d["signal_ids"][:20] if s in sig_map),
                key=lambda t: t[3], reverse=True,
            )[:5]
            d["signal_samples"] = [
                {
                    "source": p[0],
                    "source_family": p[1],
                    "content": p[2][:200],
                    "weighted_score": p[3],
                }
                for p in picks
            ]
            source_counts: dict = {}
            for p in picks:
                source_counts[p[0]] = source_counts.get(p[0], 0) + 1
            d["source_breakdown"] = source_counts

        return rows


def delete_pattern(pattern_id: str) -> bool:
    """Permanently delete a junk pattern and its constraint breaks.
    
    Does NOT delete the underlying signals — those stay in the corpus.
    On the next cluster run a different (hopefully better) cluster forms.
    """
    with _pg() as conn, conn.cursor() as cur:
        cur.execute(
            "DELETE FROM constraint_break WHERE pattern_id = %s;",
            (pattern_id,)
        )
        cur.execute(
            "DELETE FROM pattern WHERE id = %s RETURNING id;",
            (pattern_id,)
        )
        found = cur.fetchone() is not None
        conn.commit()
    return found


def mark_reviewed(pattern_id: str) -> bool:
    """Mark a pattern as reviewed — lifts it past the calibration gate."""
    with _pg() as conn, conn.cursor() as cur:
        cur.execute(
            "UPDATE pattern SET reviewed = true WHERE id = %s RETURNING id;",
            (pattern_id,)
        )
        found = cur.fetchone() is not None
        conn.commit()
    return found
