"""Layer 3a: Embedding — SBERT → Weaviate.

Encodes signal content using all-MiniLM-L6-v2 (CPU-fine, 384-dim vectors)
and upserts into Weaviate with the signal metadata. Idempotent: re-embedding
the same signal_id is a no-op.

Model is loaded once at module level and reused across calls — sentence-
transformers caches the weights after first load (~80MB).
"""
from __future__ import annotations
import logging
import os
from typing import TYPE_CHECKING

import weaviate
from sentence_transformers import SentenceTransformer

if TYPE_CHECKING:
    pass

log = logging.getLogger("prism.layers.embedding")

_model: SentenceTransformer | None = None
WEAVIATE_CLASS = "PrismSignal"
EMBED_MODEL = os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")


def _get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        log.info("loading embedding model %s", EMBED_MODEL)
        _model = SentenceTransformer(EMBED_MODEL)
    return _model


def _weaviate_client() -> weaviate.WeaviateClient:
    url = os.getenv("WEAVIATE_URL", "http://weaviate:8080")
    host = url.replace("http://", "").replace("https://", "").split(":")[0]
    port = int(url.split(":")[-1]) if ":" in url.split("//")[-1] else 8080
    return weaviate.connect_to_local(host=host, port=port)


def _ensure_schema(client: weaviate.WeaviateClient) -> None:
    """Create PrismSignal class if it doesn't exist."""
    from weaviate.classes.config import Configure, Property, DataType
    if client.collections.exists(WEAVIATE_CLASS):
        return
    client.collections.create(
        name=WEAVIATE_CLASS,
        vectorizer_config=Configure.Vectorizer.none(),  # we supply vectors
        properties=[
            Property(name="signal_id",     data_type=DataType.TEXT),
            Property(name="source",        data_type=DataType.TEXT),
            Property(name="source_family", data_type=DataType.TEXT),
            Property(name="content",       data_type=DataType.TEXT),
            Property(name="tags",          data_type=DataType.TEXT_ARRAY),
            Property(name="entities",      data_type=DataType.TEXT_ARRAY),
            Property(name="weighted_score",data_type=DataType.NUMBER),
        ],
    )
    log.info("created Weaviate class %s", WEAVIATE_CLASS)


from db.pool import connection as _pg


def embed_pending(batch_size: int = 64) -> dict:
    """Embed all signals not yet in Weaviate. Returns counts."""
    model = _get_model()
    client = _weaviate_client()
    try:
        _ensure_schema(client)
        collection = client.collections.get(WEAVIATE_CLASS)

        # Get IDs already embedded
        existing = {
            o.properties["signal_id"]
            for o in collection.iterator(return_properties=["signal_id"])
        }

        # Fetch unembedded signals from Postgres
        with _pg() as conn, conn.cursor() as cur:
            cur.execute(
                """SELECT id, source, source_family, content, tags, entities, weighted_score
                   FROM signal
                   WHERE weighted_score > 0
                   ORDER BY timestamp DESC;"""
            )
            rows = cur.fetchall()

        pending = [r for r in rows if r[0] not in existing]
        if not pending:
            log.info("embed_pending: nothing to embed")
            return {"embedded": 0, "skipped": len(existing)}

        # Batch encode
        texts = [r[3] for r in pending]
        log.info("embedding %d signals in batches of %d", len(pending), batch_size)
        vectors = model.encode(texts, batch_size=batch_size, show_progress_bar=False)

        # Upsert to Weaviate
        with collection.batch.dynamic() as batch:
            for row, vec in zip(pending, vectors):
                sid, source, family, content, tags, entities, wscore = row
                batch.add_object(
                    properties={
                        "signal_id":     sid,
                        "source":        source,
                        "source_family": family,
                        "content":       content,
                        "tags":          tags if isinstance(tags, list) else [],
                        "entities":      entities if isinstance(entities, list) else [],
                        "weighted_score": float(wscore or 0),
                    },
                    vector=vec.tolist(),
                )

        log.info("embedded %d signals", len(pending))
        return {"embedded": len(pending), "skipped": len(existing)}
    finally:
        client.close()


def semantic_search(query: str, limit: int = 10) -> list[dict]:
    """Search signals by semantic similarity to a query string."""
    model = _get_model()
    client = _weaviate_client()
    try:
        collection = client.collections.get(WEAVIATE_CLASS)
        vec = model.encode([query])[0].tolist()
        results = collection.query.near_vector(
            near_vector=vec,
            limit=limit,
            return_properties=["signal_id", "source", "source_family",
                               "content", "tags", "weighted_score"],
        )
        return [
            {
                "signal_id":     o.properties["signal_id"],
                "source":        o.properties["source"],
                "source_family": o.properties["source_family"],
                "content":       o.properties["content"][:200],
                "tags":          o.properties.get("tags", []),
                "weighted_score":o.properties.get("weighted_score", 0),
                "distance":      o.metadata.distance if o.metadata else None,
            }
            for o in results.objects
        ]
    finally:
        client.close()
