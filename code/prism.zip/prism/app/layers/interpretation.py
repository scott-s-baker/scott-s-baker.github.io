"""Layer 4: Interpretation — four constrained LLM prompts.

Implements the design doc's interpretation pipeline exactly:
  Prompt 1: Pattern compression → X→Y direction statement
  Prompt 2: Constraint identification → which assumption is broken
  Prompt 3: Decision enforcement → binary A/B with HOLD trigger
  Prompt 4: Impact framing → urgency, time horizon, affected area

Each prompt runs at temperature=0 (deterministic), with strict output
format validation. Outputs that don't match the schema are rejected and
the pattern is flagged needs_review rather than silently passing bad data
to the decision engine.

The LLM provider (Ollama/Claude) is swapped via LLM_PROVIDER env var —
no code change required (see llm/__init__.py).
"""
from __future__ import annotations
import json
import logging
import re
from dataclasses import dataclass
from typing import Literal

log = logging.getLogger("prism.layers.interpretation")

# ── Output schemas ─────────────────────────────────────────────────────────────

@dataclass
class DirectionResult:
    from_state: str        # "X" in X→Y
    to_state: str          # "Y" in X→Y
    because: str           # one-sentence evidence summary
    raw: str               # raw LLM output for audit


@dataclass
class ConstraintResult:
    assumption_id: str     # e.g. "ASSUME-001"
    assumption_text: str
    broken_because: str
    affected_area: str
    raw: str


@dataclass
class DecisionResult:
    decision_type: Literal[
        "FULL_REPOSITION", "MESSAGING_ACCENT", "FRAMING_SHIFT", "HOLD_WITH_TRIGGER"
    ]
    option_a: str
    option_b: str
    b_trigger: str | None  # required when decision_type == HOLD_WITH_TRIGGER
    raw: str


@dataclass
class ImpactResult:
    urgency: Literal["low", "medium", "high"]
    time_horizon: Literal["short", "medium", "long"]
    affected_area: Literal["narrative", "product", "pricing", "field"]
    impact_statement: str
    raw: str


@dataclass
class InterpretationResult:
    pattern_id: str
    direction: DirectionResult | None
    constraint: ConstraintResult | None
    decision: DecisionResult | None
    impact: ImpactResult | None
    status: str            # "ok" | "partial" | "rejected"
    error: str | None


# ── Prompt templates ───────────────────────────────────────────────────────────

_P1_SYSTEM = """You are a market signal analyst for enterprise storage.
Your job is to compress a cluster of market signals into a single direction statement.
The statement must follow the EXACT format:
  FROM: <current market state, max 10 words>
  TO: <emerging market state, max 10 words>
  BECAUSE: <one sentence evidence summary, max 25 words>

Do not add any other text. Do not explain. Do not hedge.
If the signals do not represent a clear directional shift, output:
  FROM: unclear
  TO: unclear
  BECAUSE: insufficient signal clarity to determine direction"""

_P1_USER = """Cluster label: {label}

Signal excerpts (most recent first):
{excerpts}

Output the FROM/TO/BECAUSE statement now:"""


_P2_SYSTEM = """You are a positioning strategist for IBM FlashSystem in EMEA.
Given a market direction shift and a list of positioning assumptions, identify which
assumption is most directly broken by this shift.

Output EXACTLY this format:
  ASSUMPTION_ID: <id from the list, e.g. ASSUME-001>
  BROKEN_BECAUSE: <one sentence, max 25 words>
  AFFECTED_AREA: <one of: narrative | product | pricing | field>

Do not add any other text."""

_P2_USER = """Market direction shift:
  FROM: {from_state}
  TO: {to_state}
  BECAUSE: {because}

Active positioning assumptions:
{assumptions_text}

Which assumption does this shift most directly break? Output now:"""


_P3_SYSTEM = """You are a positioning decision engine for IBM FlashSystem EMEA.
Every positioning question reduces to a binary choice. Output EXACTLY four lines, nothing else:

DECISION_TYPE: <one of: FULL_REPOSITION | MESSAGING_ACCENT | FRAMING_SHIFT | HOLD_WITH_TRIGGER>
OPTION_A: <concrete action, max 12 words, no quotes>
OPTION_B: <alternative action, max 12 words, no quotes, never include trigger text here>
B_TRIGGER: <only if HOLD_WITH_TRIGGER: the observable event that fires action, max 15 words>

Decision type rules:
- FULL_REPOSITION: lead narrative must change entirely
- MESSAGING_ACCENT: same narrative, different emphasis
- FRAMING_SHIFT: same content, different context or angle
- HOLD_WITH_TRIGGER: wait and watch — B_TRIGGER line is MANDATORY, must be its own line

Critical format rules:
- B_TRIGGER must be on its OWN line starting with "B_TRIGGER:"
- Never put trigger conditions inside OPTION_A or OPTION_B
- No quotes, no markdown, no bullet points, no explanation
- If not HOLD_WITH_TRIGGER, omit the B_TRIGGER line entirely"""

_P3_USER = """Broken assumption:
  [{assumption_id}] {assumption_text}
  Broken because: {broken_because}
  Affected area: {affected_area}

Output the binary decision now:"""


_P4_SYSTEM = """You are a sales strategy prioritization engine.
Given a positioning decision, output an impact frame in EXACTLY this format:

  URGENCY: <one of: low | medium | high>
  TIME_HORIZON: <one of: short | medium | long>
  AFFECTED_AREA: <one of: narrative | product | pricing | field>
  IMPACT: <one sentence, max 25 words, starting with an active verb>

Rules:
- high urgency = competitors have already moved, deal risk is immediate
- medium urgency = shift is confirmed but not yet at deal level
- low urgency = emerging signal, monitor only
- short = <30 days, medium = 30-90 days, long = >90 days
- Do not add any other text"""

_P4_USER = """Decision:
  Type: {decision_type}
  Option A: {option_a}
  Option B: {option_b}
  Broken assumption: [{assumption_id}] {assumption_text}
  Signal tier: {signal_tier}

Output the impact frame now:"""


# ── Parsers ────────────────────────────────────────────────────────────────────

def _parse_direction(raw: str) -> DirectionResult | None:
    lines = {
        m.group(1).strip(): m.group(2).strip()
        for line in raw.strip().splitlines()
        if (m := re.match(r"^(FROM|TO|BECAUSE):\s*(.+)", line.strip()))
    }
    if not all(k in lines for k in ("FROM", "TO", "BECAUSE")):
        return None
    return DirectionResult(
        from_state=lines["FROM"],
        to_state=lines["TO"],
        because=lines["BECAUSE"],
        raw=raw,
    )


def _parse_constraint(raw: str, assumptions: list) -> ConstraintResult | None:
    lines = {
        m.group(1).strip(): m.group(2).strip()
        for line in raw.strip().splitlines()
        if (m := re.match(r"^(ASSUMPTION_ID|BROKEN_BECAUSE|AFFECTED_AREA):\s*(.+)", line.strip()))
    }
    if not all(k in lines for k in ("ASSUMPTION_ID", "BROKEN_BECAUSE", "AFFECTED_AREA")):
        return None
    aid = lines["ASSUMPTION_ID"]
    # Look up assumption text
    atext = next((a.statement for a in assumptions if a.id == aid), f"(unknown: {aid})")
    area = lines["AFFECTED_AREA"]
    if area not in ("narrative", "product", "pricing", "field"):
        area = "narrative"
    return ConstraintResult(
        assumption_id=aid,
        assumption_text=atext,
        broken_because=lines["BROKEN_BECAUSE"],
        affected_area=area,
        raw=raw,
    )


_VALID_DECISION_TYPES = {
    "FULL_REPOSITION", "MESSAGING_ACCENT", "FRAMING_SHIFT", "HOLD_WITH_TRIGGER"
}

def _extract_trigger_from_text(text):
    import re as _r
    pat = r"(?:trigger|when)[: ]+.{0,5}?([A-Z][^|]{10,80})"
    m = _r.search(pat, text, _r.IGNORECASE)
    if m:
        t = m.group(1).strip().strip('"').strip(chr(39))
        if len(t) >= 10:
            return t
    m = _r.search(r"only when (.{10,60})", text, _r.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


def _parse_decision(raw: str) -> DecisionResult | None:
    lines = {
        m.group(1).strip(): m.group(2).strip()
        for line in raw.strip().splitlines()
        if (m := re.match(r"^(DECISION_TYPE|OPTION_A|OPTION_B|B_TRIGGER):\s*(.+)", line.strip()))
    }
    if not all(k in lines for k in ("DECISION_TYPE", "OPTION_A", "OPTION_B")):
        return None
    dtype = lines["DECISION_TYPE"]
    if dtype not in _VALID_DECISION_TYPES:
        return None
    trigger = lines.get("B_TRIGGER")
    option_b = lines["OPTION_B"]

    if dtype == "HOLD_WITH_TRIGGER" and not trigger:
        trigger = _extract_trigger_from_text(option_b)
        if not trigger:
            trigger = _extract_trigger_from_text(lines["OPTION_A"])

    if not option_b or option_b.upper() in ("HOLD", "HOLD PENDING TRIGGER"):
        option_b = "HOLD pending trigger"

    if dtype == "HOLD_WITH_TRIGGER" and not trigger:
        dtype = "FRAMING_SHIFT"
        trigger = None

    return DecisionResult(
        decision_type=dtype,
        option_a=lines["OPTION_A"],
        option_b=option_b,
        b_trigger=trigger,
        raw=raw,
    )
_VALID_URGENCY = {"low", "medium", "high"}
_VALID_HORIZON = {"short", "medium", "long"}
_VALID_AREA = {"narrative", "product", "pricing", "field"}

def _parse_impact(raw: str) -> ImpactResult | None:
    lines = {
        m.group(1).strip(): m.group(2).strip()
        for line in raw.strip().splitlines()
        if (m := re.match(r"^(URGENCY|TIME_HORIZON|AFFECTED_AREA|IMPACT):\s*(.+)", line.strip()))
    }
    if not all(k in lines for k in ("URGENCY", "TIME_HORIZON", "AFFECTED_AREA", "IMPACT")):
        return None
    if lines["URGENCY"] not in _VALID_URGENCY:
        return None
    if lines["TIME_HORIZON"] not in _VALID_HORIZON:
        return None
    area = lines["AFFECTED_AREA"]
    if area not in _VALID_AREA:
        area = "narrative"
    return ImpactResult(
        urgency=lines["URGENCY"],
        time_horizon=lines["TIME_HORIZON"],
        affected_area=area,
        impact_statement=lines["IMPACT"],
        raw=raw,
    )


# ── Main interpretation pipeline ───────────────────────────────────────────────

def interpret_pattern(
    pattern_id: str,
    label: str,
    signal_excerpts: list[str],
    signal_tier: str,
    assumptions: list,
) -> InterpretationResult:
    """Run all four prompts for one pattern. Returns InterpretationResult."""
    from llm import get_provider
    llm = get_provider()

    # ── Prompt 1: Direction ────────────────────────────────────────────────────
    excerpts_text = "\n".join(f"- {e[:120]}" for e in signal_excerpts[:10])
    try:
        raw1 = llm.complete(
            system=_P1_SYSTEM,
            user=_P1_USER.format(label=label, excerpts=excerpts_text),
        )
        direction = _parse_direction(raw1)
    except Exception as e:
        log.error("P1 failed for %s: %s", pattern_id, e)
        return InterpretationResult(
            pattern_id=pattern_id, direction=None, constraint=None,
            decision=None, impact=None, status="rejected", error=str(e)
        )

    if not direction or direction.from_state == "unclear":
        log.info("P1 rejected for %s: unclear direction", pattern_id)
        return InterpretationResult(
            pattern_id=pattern_id, direction=direction, constraint=None,
            decision=None, impact=None, status="rejected",
            error="insufficient signal clarity"
        )

    # ── Prompt 2: Constraint ───────────────────────────────────────────────────
    assumptions_text = "\n".join(
        f"{i+1}. [{a.id}] {a.statement}" for i, a in enumerate(assumptions)
    )
    try:
        raw2 = llm.complete(
            system=_P2_SYSTEM,
            user=_P2_USER.format(
                from_state=direction.from_state,
                to_state=direction.to_state,
                because=direction.because,
                assumptions_text=assumptions_text,
            ),
        )
        constraint = _parse_constraint(raw2, assumptions)
    except Exception as e:
        log.error("P2 failed for %s: %s", pattern_id, e)
        constraint = None

    if not constraint:
        return InterpretationResult(
            pattern_id=pattern_id, direction=direction, constraint=None,
            decision=None, impact=None, status="partial",
            error="constraint parse failed"
        )

    # ── Prompt 3: Decision ─────────────────────────────────────────────────────
    try:
        raw3 = llm.complete(
            system=_P3_SYSTEM,
            user=_P3_USER.format(
                assumption_id=constraint.assumption_id,
                assumption_text=constraint.assumption_text,
                broken_because=constraint.broken_because,
                affected_area=constraint.affected_area,
            ),
        )
        decision = _parse_decision(raw3)
    except Exception as e:
        log.error("P3 failed for %s: %s", pattern_id, e)
        decision = None

    if not decision:
        return InterpretationResult(
            pattern_id=pattern_id, direction=direction, constraint=constraint,
            decision=None, impact=None, status="partial",
            error="decision parse failed"
        )

    # ── Prompt 4: Impact ───────────────────────────────────────────────────────
    try:
        raw4 = llm.complete(
            system=_P4_SYSTEM,
            user=_P4_USER.format(
                decision_type=decision.decision_type,
                option_a=decision.option_a,
                option_b=decision.option_b,
                assumption_id=constraint.assumption_id,
                assumption_text=constraint.assumption_text,
                signal_tier=signal_tier,
            ),
        )
        impact = _parse_impact(raw4)
    except Exception as e:
        log.error("P4 failed for %s: %s", pattern_id, e)
        impact = None

    # Tier-anchored urgency floor.
    # The LLM tends to default low; enforce minimums from signal evidence.
    # CONFIRMED tier must produce at least medium urgency.
    # ESTABLISHED tier must produce at least high urgency.
    if impact:
        _tier_floor = {"CONFIRMED": "medium", "ESTABLISHED": "high"}
        _floor = _tier_floor.get(signal_tier)
        _urgency_rank = {"low": 0, "medium": 1, "high": 2}
        if _floor and _urgency_rank.get(impact.urgency, 0) < _urgency_rank[_floor]:
            log.info(
                "urgency floor applied: %s → %s (tier=%s)",
                impact.urgency, _floor, signal_tier
            )
            from dataclasses import replace as _replace
            impact = _replace(impact, urgency=_floor)

    status = "ok" if impact else "partial"
    return InterpretationResult(
        pattern_id=pattern_id,
        direction=direction,
        constraint=constraint,
        decision=decision,
        impact=impact,
        status=status,
        error=None if status == "ok" else "impact parse failed",
    )
