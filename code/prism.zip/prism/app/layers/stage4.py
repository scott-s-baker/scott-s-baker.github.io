"""Stage 4 orchestrator — interprets reviewed patterns into Decision objects.

Pulls patterns where reviewed=True and not yet interpreted, fetches signal
content from Postgres, runs the four-prompt interpretation pipeline, and
writes results to the constraint_break and decision tables.

During calibration (reviewed=False), patterns are skipped — the review gate
is enforced upstream in clustering.py but double-checked here.
"""
from __future__ import annotations
import json
import logging
import os
import uuid
from datetime import date, datetime, timezone

log = logging.getLogger("prism.layers.stage4")


from db.pool import connection as _pg


def _fetch_signal_content(signal_ids: list[str], conn) -> list[str]:
    """Fetch content for a list of signal IDs, ordered by timestamp desc."""
    with conn.cursor() as cur:
        cur.execute(
            """SELECT content FROM signal
               WHERE id = ANY(%s)
               ORDER BY timestamp DESC;""",
            (signal_ids,)
        )
        return [r[0] for r in cur.fetchall()]


def run_interpretation(force: bool = False) -> dict:
    """
    Interpret all reviewed, uninterpreted patterns.
    force=True re-interprets patterns that already have a decision.
    Returns summary dict.
    """
    from layers.assumptions import load_assumptions
    from layers.interpretation import interpret_pattern

    assumptions = load_assumptions()
    if not assumptions:
        return {
            "status": "error",
            "error": "No active assumptions — check config/positioning_assumptions.yaml"
        }

    ok = partial = rejected = skipped = 0

    with _pg() as conn:
        # Fetch reviewed patterns
        with conn.cursor() as cur:
            cur.execute(
                """SELECT p.id, p.direction, p.signal_tier, p.signal_ids
                   FROM pattern p
                   WHERE p.reviewed = true
                   ORDER BY p.created_at DESC;"""
            )
            patterns = cur.fetchall()

        if not patterns:
            return {
                "status": "ok",
                "message": "No reviewed patterns to interpret. Use POST /patterns/{id}/review to lift a pattern past the calibration gate.",
                "ok": 0, "partial": 0, "rejected": 0, "skipped": 0,
            }

        for pat_id, label, tier, signal_ids_raw in patterns:
            # Check if already interpreted
            if not force:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT id FROM decision WHERE id LIKE %s LIMIT 1;",
                        (f"%{pat_id[:16]}%",)
                    )
                    if cur.fetchone():
                        skipped += 1
                        continue

            # Fetch signal content
            if isinstance(signal_ids_raw, str):
                signal_ids = json.loads(signal_ids_raw)
            else:
                signal_ids = signal_ids_raw or []

            excerpts = _fetch_signal_content(signal_ids, conn)
            if not excerpts:
                log.warning("pattern %s has no signal content", pat_id)
                skipped += 1
                continue

            log.info("interpreting pattern %s (%d signals)", pat_id, len(excerpts))

            # Run four-prompt pipeline
            result = interpret_pattern(
                pattern_id=pat_id,
                label=label or "unlabelled cluster",
                signal_excerpts=excerpts,
                signal_tier=tier or "EMERGING",
                assumptions=assumptions,
            )

            if result.status == "rejected":
                rejected += 1
                log.info("pattern %s rejected: %s", pat_id, result.error)
                continue

            # Write constraint_break
            if result.constraint:
                cb_id = f"cb_{pat_id[:20]}_{uuid.uuid4().hex[:8]}"
                with conn.cursor() as cur:
                    cur.execute(
                        """INSERT INTO constraint_break
                             (id, pattern_id, assumption_id, assumption_text,
                              broken_because, affected_area)
                           VALUES (%s, %s, %s, %s, %s, %s)
                           ON CONFLICT (id) DO NOTHING;""",
                        (
                            cb_id,
                            pat_id,
                            result.constraint.assumption_id,
                            result.constraint.assumption_text,
                            result.constraint.broken_because,
                            result.constraint.affected_area,
                        )
                    )

            # Write decision
            if result.decision:
                # Deterministic ID: same pattern + decision type = same ID.
                # Prevents force=True from creating duplicate decisions.
                import hashlib as _hl
                _dec_hash = _hl.sha256(
                    f"{pat_id}|{result.decision.decision_type}|{result.decision.option_a[:30]}".encode()
                ).hexdigest()[:8]
                dec_id = f"dec_{pat_id[:20]}_{_dec_hash}"
                from datetime import timedelta
                _days = (5 if result.impact.urgency == "high" else
                         14 if result.impact.urgency == "medium" else 30)
                commit_by = date.today() + timedelta(days=_days)

                direction_str = (
                    f"{result.direction.from_state} → {result.direction.to_state}"
                    if result.direction else label
                )
                constraint_str = (
                    result.constraint.broken_because
                    if result.constraint else ""
                )

                with conn.cursor() as cur:
                    cur.execute(
                        """INSERT INTO decision
                             (id, model, signal, constraint_txt, decision_type,
                              option_a, option_b, b_trigger, impact, urgency,
                              time_horizon, commit_by, decision_owner, status)
                           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                           ON CONFLICT (id) DO NOTHING;""",
                        (
                            dec_id,
                            "axis_shift",
                            direction_str,
                            constraint_str,
                            result.decision.decision_type,
                            result.decision.option_a,
                            result.decision.option_b,
                            result.decision.b_trigger,
                            result.impact.impact_statement if result.impact else None,
                            result.impact.urgency if result.impact else "low",
                            result.impact.time_horizon if result.impact else "long",
                            commit_by,
                            "PMM Lead",
                            "OPEN",
                        )
                    )

            conn.commit()

            if result.status == "ok":
                ok += 1
            else:
                partial += 1

    return {
        "status": "ok",
        "interpreted_ok": ok,
        "interpreted_partial": partial,
        "rejected": rejected,
        "skipped": skipped,
        "assumptions_active": len(assumptions),
    }


def get_decisions(status: str | None = None) -> list[dict]:
    """Fetch decisions from Postgres, optionally filtered by status."""
    with _pg() as conn, conn.cursor() as cur:
        if status:
            cur.execute(
                """SELECT id, model, signal, constraint_txt, decision_type,
                          option_a, option_b, b_trigger, impact, urgency,
                          time_horizon, commit_by, decision_owner, status,
                          notes, review_30d, review_60d, review_90d,
                          decided_at, created_at
                   FROM decision WHERE status = %s ORDER BY commit_by ASC;""",
                (status,)
            )
        else:
            cur.execute(
                """SELECT id, model, signal, constraint_txt, decision_type,
                          option_a, option_b, b_trigger, impact, urgency,
                          time_horizon, commit_by, decision_owner, status,
                          notes, review_30d, review_60d, review_90d,
                          decided_at, created_at
                   FROM decision ORDER BY commit_by ASC;"""
            )
        cols = [d[0] for d in cur.description]
        rows = []
        for row in cur.fetchall():
            d = dict(zip(cols, row))
            for k in ("commit_by", "created_at"):
                if hasattr(d.get(k), "isoformat"):
                    d[k] = d[k].isoformat()
            rows.append(d)
        return rows


def update_decision_status(decision_id: str, status: str, notes: str = "") -> bool:
    valid = {"OPEN", "DECIDED-A", "DECIDED-B", "DEFERRED", "EXPIRED"}
    if status not in valid:
        return False
    with _pg() as conn, conn.cursor() as cur:
        # NULLIF guard: empty notes must not wipe notes already on the row
        cur.execute(
            """UPDATE decision
               SET status = %s,
                   notes = COALESCE(NULLIF(%s, ''), notes),
                   decided_at = %s
               WHERE id = %s RETURNING id;""",
            (status, notes, datetime.now(timezone.utc), decision_id)
        )
        found = cur.fetchone() is not None
        conn.commit()
    return found
