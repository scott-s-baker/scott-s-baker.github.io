"""Provider-agnostic LLM interface.

Switching LLM_PROVIDER in .env between 'ollama' and 'claude' changes the
entire interpretation + decision layer with no code change. This is the
model-agnosticism the design doc requires (mitigates the 'watsonx quality
insufficient' risk in the register).
"""
from __future__ import annotations
import os
from abc import ABC, abstractmethod


class LLMProvider(ABC):
    @abstractmethod
    def complete(self, system: str, user: str, *, temperature: float = 0.0) -> str:
        """Return raw text completion. Prompts are tightly constrained upstream."""
        ...


def get_provider() -> "LLMProvider":
    provider = os.getenv("LLM_PROVIDER", "ollama").lower()
    if provider == "ollama":
        from .ollama_provider import OllamaProvider
        return OllamaProvider()
    if provider == "claude":
        from .claude_provider import ClaudeProvider
        return ClaudeProvider()
    raise ValueError(f"Unknown LLM_PROVIDER: {provider!r} (expected 'ollama' or 'claude')")
