"""Claude provider — higher interpretation quality for calibration.

Boots without a key (stub mode) so the stack comes up clean. Set
ANTHROPIC_API_KEY in .env and flip LLM_PROVIDER=claude to activate.
"""
import os
from . import LLMProvider


class ClaudeProvider(LLMProvider):
    def __init__(self) -> None:
        self.api_key = os.getenv("ANTHROPIC_API_KEY", "")
        self.model = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")
        self._client = None
        if self.api_key:
            from anthropic import Anthropic
            self._client = Anthropic(api_key=self.api_key)

    def complete(self, system: str, user: str, *, temperature: float = 0.0) -> str:
        if self._client is None:
            raise RuntimeError(
                "ClaudeProvider is stubbed: set ANTHROPIC_API_KEY in .env to activate, "
                "or keep LLM_PROVIDER=ollama."
            )
        msg = self._client.messages.create(
            model=self.model,
            max_tokens=1024,
            temperature=temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in msg.content if b.type == "text").strip()
