"""Ollama provider — default. Points at a separate Proxmox host running Ollama.

For the constrained X->Y extraction prompts in this system, an 8B model
(llama3.1:8b / mistral) is sufficient — these are not open-generation tasks.
"""
import os
import httpx
from . import LLMProvider

# Shared client — keep-alive avoids a new TCP connection per prompt
# (the 4-prompt pipeline hits Ollama 4x per pattern)
_client = httpx.Client(timeout=120.0)


class OllamaProvider(LLMProvider):
    def __init__(self) -> None:
        self.base_url = os.environ["OLLAMA_BASE_URL"].rstrip("/")
        self.model = os.getenv("OLLAMA_MODEL", "llama3.1:8b")

    def complete(self, system: str, user: str, *, temperature: float = 0.0) -> str:
        resp = _client.post(
            f"{self.base_url}/api/chat",
            json={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "options": {"temperature": temperature},
            },
        )
        resp.raise_for_status()
        return resp.json()["message"]["content"].strip()
