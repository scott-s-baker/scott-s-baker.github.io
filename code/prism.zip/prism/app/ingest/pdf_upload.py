"""Manual analyst PDF upload (design doc Layer 1: analyst research via manual upload).

For Gartner/Forrester PDFs that aren't in an RSS feed. Extracts text, splits
into paragraph-sized signals, tags, and writes as source='analyst' (1.0x).
Use the upload date or pass the report's publish date for correct recency.
"""
from __future__ import annotations
import logging
from datetime import datetime, timezone
from pypdf import PdfReader

from ingest.tagging import extract_entities, extract_tags

log = logging.getLogger("prism.ingest.pdf")


def ingest_pdf(
    path: str,
    *,
    source_family: str,
    publish_date: datetime | None = None,
    min_len: int = 120,
) -> dict:
    from db.repository import upsert_signal
    ts = publish_date or datetime.now(timezone.utc)
    reader = PdfReader(path)
    inserted = scanned = 0
    for page in reader.pages:
        text = page.extract_text() or ""
        for para in (p.strip() for p in text.split("\n\n")):
            if len(para) < min_len:
                continue
            scanned += 1
            row = upsert_signal(
                source="analyst",
                source_family=source_family,
                timestamp=ts,
                content=" ".join(para.split()),
                entities=extract_entities(para),
                tags=extract_tags(para),
            )
            inserted += int(row["inserted"])
    log.info("pdf %s: %d scanned, %d new", source_family, scanned, inserted)
    return {"source": "analyst_pdf", "family": source_family, "scanned": scanned, "inserted": inserted}
