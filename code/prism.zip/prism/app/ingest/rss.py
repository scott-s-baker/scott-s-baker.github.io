"""Analyst + press RSS collector (design doc Layer 1).

RSS entries carry real publish dates, so recency weighting is meaningful here
(unlike scraped hero copy). source='analyst' -> 1.0x; source='press' -> 0.5x,
applied automatically by Layer 2.

Feed list is config-driven. Each feed declares its source category so the
right independence weight is applied. source_family is the publisher domain
(the dedup key — many items from one publisher count as one signal at tier time).

v1.1: httpx-based fetcher with hard per-feed timeout replaces feedparser's
      urllib which ignores socket timeouts on SSL/chunked responses.
      businesswire and computerweekly removed (timeout/404).
"""
from __future__ import annotations
import logging
from datetime import datetime, timezone
from time import mktime
import feedparser

from ingest.tagging import extract_entities, extract_tags

log = logging.getLogger("prism.ingest.rss")

RSS_FEEDS = [
    # ── ANALYST (1.0x) ────────────────────────────────────────────────────────
    {"family": "dcig.com",           "source": "analyst", "url": "https://dcig.com/feed/"},
    {"family": "futurumgroup.com",   "source": "analyst", "url": "https://futurumgroup.com/insights/feed/"},

    # ── STORAGE PRESS (0.5x) ──────────────────────────────────────────────────
    {"family": "blocksandfiles.com", "source": "press",   "url": "https://blocksandfiles.com/feed/"},
    {"family": "storagenewsletter",  "source": "press",   "url": "https://www.storagenewsletter.com/feed/"},
    {"family": "theregister-storage","source": "press",   "url": "https://www.theregister.com/on_prem/storage/headlines.atom"},
    {"family": "theregister-all",    "source": "press",   "url": "https://www.theregister.com/headlines.atom"},

    # ── ENTERPRISE IT PRESS (0.5x) ────────────────────────────────────────────
    {"family": "cio.com",            "source": "press",   "url": "https://www.cio.com/feed/"},
    {"family": "computerworld.com",  "source": "press",   "url": "https://www.computerworld.com/feed/"},
    {"family": "itpro.com-storage",  "source": "press",   "url": "https://www.itpro.com/feeds/tag/cloud-storage"},
    {"family": "datacenterdynamics", "source": "press",   "url": "https://www.datacenterdynamics.com/en/rss/"},
    {"family": "zdnet.com",          "source": "press",   "url": "https://www.zdnet.com/news/rss.xml"},
    {"family": "techrepublic.com",   "source": "press",   "url": "https://www.techrepublic.com/rssfeeds/articles/"},
    {"family": "eweek.com",          "source": "press",   "url": "https://www.eweek.com/feed/"},

    # ── VENDOR BLOGS (0.5x — editorial, not product copy) ────────────────────
    {"family": "purestorage-blog",   "source": "press",   "url": "https://blog.purestorage.com/feed/"},
]

_FETCH_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; PrismDIA/1.1; +https://prism.internal)",
    "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml",
}


def _fetch_feed(url: str, timeout: float = 15.0) -> str | None:
    """Fetch RSS/Atom feed with hard timeout using httpx.
    
    feedparser's urllib ignores socket timeouts on SSL/chunked responses.
    httpx enforces a real wall-clock timeout.
    """
    try:
        import httpx
        r = httpx.get(url, timeout=timeout, follow_redirects=True, headers=_FETCH_HEADERS)
        r.raise_for_status()
        return r.text
    except Exception as e:
        log.warning("feed fetch failed %s: %s", url, e)
        return None


def _entry_time(entry) -> datetime:
    for key in ("published_parsed", "updated_parsed"):
        t = entry.get(key)
        if t:
            return datetime.fromtimestamp(mktime(t), tz=timezone.utc)
    return datetime.now(timezone.utc)


def _entry_text(entry) -> str:
    title = entry.get("title", "").strip()
    summary = entry.get("summary", "").strip()
    # strip HTML crudely from summary
    if "<" in summary:
        try:
            from bs4 import BeautifulSoup
            summary = BeautifulSoup(summary, "html.parser").get_text(" ", strip=True)
        except Exception:
            import re
            summary = re.sub(r"<[^>]+>", " ", summary).strip()
    return f"{title}. {summary}".strip(". ").strip()


def collect_rss(feeds: list[dict] | None = None) -> dict:
    from db.repository import upsert_signal
    from db.pool import connection as db_conn
    feeds = feeds if feeds is not None else RSS_FEEDS
    inserted = scanned = 0
    with db_conn() as conn:
        for feed in feeds:
            raw = _fetch_feed(feed["url"])
            if raw is None:
                continue
            parsed = feedparser.parse(raw)
            if parsed.bozo:
                log.warning("feed parse issue %s: %s", feed["family"], parsed.get("bozo_exception"))
            for entry in parsed.entries:
                text = _entry_text(entry)
                if len(text) < 20:
                    continue
                scanned += 1
                try:
                    row = upsert_signal(
                        source=feed["source"],
                        source_family=feed["family"],
                        timestamp=_entry_time(entry),
                        content=text,
                        entities=extract_entities(text),
                        tags=extract_tags(text),
                        conn=conn,
                    )
                    inserted += int(row["inserted"])
                except Exception as e:
                    log.warning("upsert failed %s: %s", feed["family"], e)
        conn.commit()
    log.info("rss collect: %d scanned, %d new", scanned, inserted)
    return {"source": "rss", "scanned": scanned, "inserted": inserted}
