"""Lightweight, deterministic tagging for ingestion.

No LLM at ingest time — keeps the pipeline cheap and fast. The interpretation
layer (Stage 4) does the semantic work; this just annotates signals so
clustering and filtering have structured handles. Vocab is the FlashSystem
competitive domain and is meant to be edited as the market moves.

v1.1: added everpure (Pure brand name on PeerSpot/G2), purity deepreduce,
      expanded agentic/AI terms, added NIS2/EU regulatory terms.
"""
from __future__ import annotations
import re

# Competitor product / company entities
COMPETITOR_ENTITIES = {
    "dell": ["powerstore", "powermax", "dell emc", "dell technologies", " dell "],
    "pure": ["pure storage", "flasharray", "flashblade", "purity", "everpure",
             "evergreen", "pure//", "//x", "//c"],
    "netapp": ["netapp", "ontap", "aff ", "fas ", "keystone", "cloud volumes"],
    "hpe": ["hpe ", "alletra", "nimble", "greenlake", "primera", "3par"],
    "huawei": ["huawei", "oceanstor", "dorado", "oceanprotect"],
    "hitachi": ["hitachi", "vsp ", "hds ", "ops center"],
    "ibm": ["flashsystem", "fcm", "fcm5", "storage insights", "safeguarded",
            "spectrum virtualize", "svc ", "flashcore"],
}

# Thematic tags (the axes the doc cares about for axis-shift detection)
TAG_PATTERNS = {
    "AI": r"\b(ai|inference|inferencing|gpu|llm|genai|copilot|rag|vector|agentic|agent[- ]driven|ai[- ]ready)\b",
    "pricing": r"\b(price|pricing|discount|cost per|tco|capacity license|subscription|evergreen|opex|capex|remedy)\b",
    "governance": r"\b(sovereignty|sovereign|compliance|audit|regulat|gdpr|nis2|dora|eu act|data residency)\b",
    "hybrid": r"\b(hybrid|multicloud|multi-cloud|on-prem|cloud-native|repatriat)\b",
    "cyber_resilience": r"\b(ransomware|cyber resilien|immutab|air[- ]gap|safeguarded|recovery|backup|restore|ml-kem|sentinel)\b",
    "performance": r"\b(latency|iops|throughput|nvme|compression|dedup|reduction|fcm|flashcore)\b",
}


def extract_entities(text: str) -> list[str]:
    lo = " " + text.lower() + " "  # pad for word-boundary matching
    found = []
    for company, terms in COMPETITOR_ENTITIES.items():
        if any(t in lo for t in terms):
            found.append(company)
    return found


def extract_tags(text: str) -> list[str]:
    lo = text.lower()
    return [tag for tag, pat in TAG_PATTERNS.items() if re.search(pat, lo)]


def normalize_content(text: str) -> str:
    """Normalize text before hashing for dedup.
    
    Collapses whitespace, strips leading/trailing space, lowercases.
    Used by repository.signal_id() to prevent whitespace-variant duplicates.
    """
    return " ".join(text.lower().split())
