"""Competitor web collector — CSS-selector targeted (design doc Layer 1:
"scraped, structured CSS selectors, not full-page dumps").

Each source declares the URL and the selector that isolates the meaningful
text (headline, hero copy, product positioning blurb). Adding a competitor =
adding a dict entry. source='competitor' -> Layer 2 applies the 0.25x
adversarial discount automatically.

Politeness: single request per source, real UA, on-demand only (scheduled by
Prefect, not hammering). Respect robots/ToS for any source you add.
"""
from __future__ import annotations
import logging
from datetime import datetime, timezone
import httpx
from bs4 import BeautifulSoup

from ingest.tagging import extract_entities, extract_tags

log = logging.getLogger("prism.ingest.competitor")

UA = "Mozilla/5.0 (compatible; PrismDIA/0.1; internal research)"

# source_family is the independence-dedup key (doc Layer 2). One family per domain.
COMPETITOR_SOURCES = [
    # {"family": "dell.com", "url": "https://www.dell.com/.../powerstore",
    #  "selector": "main h1, main .hero-copy, .product-hero p"},
    # {"family": "purestorage.com", "url": "https://www.purestorage.com/products/...",
    #  "selector": "h1, .hero__subtitle, .product-overview p"},
    # Fill with real URLs + selectors during Phase 0 source mapping.
    # Left empty so the collector is safe to run before you've curated sources.
]


def _fetch(url: str) -> str:
    resp = httpx.get(url, headers={"User-Agent": UA}, timeout=30.0, follow_redirects=True)
    resp.raise_for_status()
    return resp.text


def _extract_blocks(html: str, selector: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    blocks = []
    for el in soup.select(selector):
        txt = " ".join(el.get_text(" ", strip=True).split())
        if len(txt) >= 20:  # drop nav fragments / empty nodes
            blocks.append(txt)
    return blocks


def collect_competitor(sources: list[dict] | None = None) -> dict:
    from db.repository import upsert_signal
    from db.pool import connection as db_conn
    sources = sources if sources is not None else COMPETITOR_SOURCES
    now = datetime.now(timezone.utc)
    inserted = scanned = 0
    with db_conn() as conn:
        for src in sources:
            try:
                html = _fetch(src["url"])
            except Exception as e:
                log.warning("fetch failed %s: %s", src["family"], e)
                continue
            for block in _extract_blocks(html, src["selector"]):
                scanned += 1
                row = upsert_signal(
                    source="competitor",
                    source_family=src["family"],
                    timestamp=now,                 # scrape time; no reliable publish date on hero copy
                    content=block,
                    entities=extract_entities(block),
                    tags=extract_tags(block),
                    conn=conn,
                )
                inserted += int(row["inserted"])
    log.info("competitor collect: %d scanned, %d new", scanned, inserted)
    return {"source": "competitor", "scanned": scanned, "inserted": inserted}


# ── Phase 2: PeerSpot review scraper ─────────────────────────────────────────

PEERSPOT_SOURCES = [
    {"family": "peerspot-ibm",    "source": "field",
     "url": "https://www.peerspot.com/products/ibm-flashsystem-reviews",
     "vendor": "ibm"},
    {"family": "peerspot-dell",   "source": "field",
     "url": "https://www.peerspot.com/products/dell-powerstore-reviews",
     "vendor": "dell"},
    {"family": "peerspot-pure",   "source": "field",
     "url": "https://www.peerspot.com/products/everpure-flasharray-reviews",
     "vendor": "pure"},
    {"family": "peerspot-netapp", "source": "field",
     "url": "https://www.peerspot.com/products/netapp-aff-a-series-reviews",
     "vendor": "netapp"},
    {"family": "peerspot-hpe",    "source": "field",
     "url": "https://www.peerspot.com/products/hpe-alletra-storage-mp-reviews",
     "vendor": "hpe"},
    {"family": "peerspot-huawei", "source": "field",
     "url": "https://www.peerspot.com/products/huawei-oceanstor-dorado-reviews",
     "vendor": "huawei"},
]

_PS_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}


def _scrape_peerspot(url: str, vendor: str, max_reviews: int = 20) -> list[str]:
    """Extract reviewBody text blocks from a PeerSpot product page."""
    import httpx
    import re
    try:
        r = httpx.get(url, timeout=20.0, follow_redirects=True, headers=_PS_HEADERS)
        r.raise_for_status()
    except Exception as e:
        log.warning("peerspot fetch failed %s: %s", vendor, e)
        return []

    raw_reviews = re.findall(r'reviewBody[":\\s]+([^"<]{80,2000})', r.text)
    if not raw_reviews:
        log.warning("peerspot: no reviewBody found for %s (%d chars)", vendor, len(r.text))
        return []

    cleaned = []
    for rv in raw_reviews[:max_reviews]:
        text = rv.replace('\\n', ' ').replace('\\r', ' ').replace('\\t', ' ')
        text = re.sub(r'\\u[0-9a-fA-F]{4}', ' ', text).strip()
        if len(text) >= 80:
            cleaned.append(text[:1500])

    log.info("peerspot %s: extracted %d reviews", vendor, len(cleaned))
    return cleaned


def collect_peerspot(sources: list[dict] | None = None) -> dict:
    """Collect PeerSpot reviews as field-weight signals."""
    from db.repository import upsert_signal
    from db.pool import connection as db_conn
    from datetime import datetime, timezone

    sources = sources if sources is not None else PEERSPOT_SOURCES
    inserted = scanned = 0
    with db_conn() as conn:
        for src in sources:
            reviews = _scrape_peerspot(src["url"], src["vendor"])
            for text in reviews:
                scanned += 1
                enriched = f"{src['vendor'].upper()} customer review: {text}"
                try:
                    row = upsert_signal(
                        source=src["source"],
                        source_family=src["family"],
                        timestamp=datetime.now(timezone.utc),
                        content=enriched,
                        entities=extract_entities(enriched),
                        tags=extract_tags(enriched),
                        conn=conn,
                    )
                    inserted += int(row["inserted"])
                except Exception as e:
                    log.warning("peerspot upsert failed %s: %s", src["family"], e)
        conn.commit()

    log.info("peerspot collect: %d scanned, %d new", scanned, inserted)
    return {"source": "peerspot", "scanned": scanned, "inserted": inserted}
