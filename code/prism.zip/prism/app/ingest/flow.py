"""Prefect flow: full pipeline — ingest → embed → cluster → interpret → stage5.

Schedule: twice daily (6am + 6pm).
Run once:  python -m ingest.flow
"""
from __future__ import annotations
import logging
from prefect import flow, task

from ingest.competitor import collect_competitor
from ingest.rss import collect_rss
from layers.embedding import embed_pending
from layers.clustering import run_clustering
from layers.stage4 import run_interpretation
from layers.stage5 import run_stage5

logging.basicConfig(level=logging.INFO)


@task(retries=2, retry_delay_seconds=30)
def task_competitor():   return collect_competitor()

@task(retries=2, retry_delay_seconds=30)
def task_rss():          return collect_rss()

@task(retries=1, retry_delay_seconds=60)
def task_embed():        return embed_pending()

@task(retries=1, retry_delay_seconds=60)
def task_cluster():      return run_clustering()

@task(retries=1, retry_delay_seconds=60)
def task_interpret():    return run_interpretation()

@task(retries=1, retry_delay_seconds=30)
def task_stage5():       return run_stage5()


@flow(name="prism-pipeline")
def prism_pipeline():
    comp    = task_competitor()
    rss     = task_rss()
    embed   = task_embed()
    clust   = task_cluster()
    interp  = task_interpret()
    s5      = task_stage5()

    deferred = s5.get("sla", {}).get("deferred", 0)
    print(
        f"[prism] signals={comp['inserted']+rss['inserted']} "
        f"embedded={embed.get('embedded',0)} "
        f"patterns={clust.get('patterns_written',0)} "
        f"decisions_ok={interp.get('interpreted_ok',0)} "
        f"deferred={deferred}"
    )
    return {
        "ingest":  {"comp": comp, "rss": rss},
        "embed":   embed,
        "cluster": clust,
        "interp":  interp,
        "stage5":  s5,
    }


if __name__ == "__main__":
    prism_pipeline()
