"""Shared Postgres connection pool.

Single pool for the whole process — replaces the per-request
psycopg.connect() calls that were previously duplicated across main.py and
every layer module. `connection()` returns a context manager: the connection
is committed on clean exit, rolled back on exception, and returned to the
pool either way (same transaction semantics as `with psycopg.connect()`).

The pool is created lazily on first use so importing this module never
blocks on the database being reachable.
"""
from __future__ import annotations
import os

from psycopg_pool import ConnectionPool

_pool: ConnectionPool | None = None


def _conninfo() -> str:
    return (
        f"host={os.getenv('PG_HOST', 'postgres')} "
        f"port={os.getenv('PG_PORT', '5432')} "
        f"dbname={os.getenv('PG_DB', 'prism')} "
        f"user={os.getenv('PG_USER', 'prism')} "
        f"password={os.getenv('PG_PASSWORD', 'prism')}"
    )


def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        _pool = ConnectionPool(_conninfo(), min_size=1, max_size=8, open=True)
    return _pool


def connection():
    """Pooled connection as a context manager."""
    return get_pool().connection()
