"""Signal persistence + Layer 2 scoring on write.

Every signal is scored through the Signal Quality Framework at insert time,
so independence_wt / recency_wt / weighted_score are never left null.
Idempotent: id is a content+source hash, so re-running a collector does not
duplicate signals (supports the doc's same-source dedup intent at the row level).

v1.1:
- Content normalized before hashing (prevents whitespace-variant duplicates)
- weighted_score stored at insert for fast reads; stage5 recalculates at
  evaluation time so tier logic is always fresh
"""
from __future__ import annotations
import json
import hashlib
from datetime import datetime, timezone

from db.pool import connection as db_conn

from layers.signal_quality import score_signal
from ingest.tagging import normalize_content


def signal_id(source: str, source_family: str, content: str) -> str:
    # Normalize before hashing to prevent whitespace-variant duplicates
    normalized = normalize_content(content)
    h = hashlib.sha256(f"{source}|{source_family}|{normalized}".encode()).hexdigest()
    return f"sig_{h[:24]}"


def upsert_signal(
    *,
    source: str,
    source_family: str,
    timestamp: datetime,
    content: str,
    entities: list[str] | None = None,
    tags: list[str] | None = None,
    conn=None,
) -> dict:
    """Insert a scored signal. Returns the row dict. ON CONFLICT DO NOTHING (idempotent)."""
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    scored = score_signal(source, timestamp)
    sid = signal_id(source, source_family, content)
    row = {
        "id": sid,
        "source": source,
        "source_family": source_family,
        "timestamp": timestamp,
        "content": content,
        "entities": entities or [],
        "tags": tags or [],
        **scored,
    }

    if conn is None:
        with db_conn() as own_conn:
            row["inserted"] = _insert_row(own_conn, row)
    else:
        row["inserted"] = _insert_row(conn, row)
    return row


def _insert_row(conn, row: dict) -> bool:
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO signal
              (id, source, source_family, timestamp, content, entities, tags,
               independence_wt, recency_wt, weighted_score)
            VALUES
              (%(id)s, %(source)s, %(source_family)s, %(timestamp)s, %(content)s,
               %(entities)s, %(tags)s, %(independence_wt)s, %(recency_wt)s, %(weighted_score)s)
            ON CONFLICT (id) DO NOTHING
            RETURNING id;
            """,
            {**row, "entities": json.dumps(row["entities"]), "tags": json.dumps(row["tags"])},
        )
        return cur.fetchone() is not None
