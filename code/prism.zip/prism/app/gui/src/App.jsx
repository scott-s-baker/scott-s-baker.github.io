import { useState, useEffect, useCallback } from "react";

const API = "http://192.168.1.104:8000";

const call = async (method, path, body) => {
  try {
    const res = await fetch(`${API}${path}`, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    return { _error: e.message };
  }
};

const get = (path) => call("GET", path);
const post = (path) => call("POST", path);

// ── Design tokens ────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0a0a0f;
    --bg1: #111118;
    --bg2: #18181f;
    --bg3: #1f1f28;
    --border: #2a2a38;
    --border2: #3a3a4a;
    --text: #e8e8f0;
    --text2: #9898b0;
    --text3: #5a5a70;
    --accent: #4a9eff;
    --accent2: #2d7adb;
    --green: #2ecc8a;
    --amber: #f0a030;
    --red: #e05060;
    --purple: #a06aff;
    --mono: 'IBM Plex Mono', monospace;
    --sans: 'IBM Plex Sans', sans-serif;
  }

  html, body, #root { height: 100%; background: var(--bg); color: var(--text); font-family: var(--sans); }

  ::-webkit-scrollbar { width: 4px; height: 4px; }
  ::-webkit-scrollbar-track { background: var(--bg1); }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 2px; }

  .app { display: flex; height: 100vh; overflow: hidden; }

  /* Sidebar */
  .sidebar {
    width: 220px; min-width: 220px;
    background: var(--bg1);
    border-right: 1px solid var(--border);
    display: flex; flex-direction: column;
    padding: 0;
  }
  .sidebar-logo {
    padding: 20px 20px 16px;
    border-bottom: 1px solid var(--border);
  }
  .logo-name {
    font-family: var(--mono); font-size: 18px; font-weight: 600;
    letter-spacing: 0.12em; color: var(--accent);
  }
  .logo-sub {
    font-size: 10px; color: var(--text3); letter-spacing: 0.08em;
    text-transform: uppercase; margin-top: 3px;
  }
  .nav { flex: 1; padding: 12px 0; }
  .nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 9px 20px; cursor: pointer;
    font-size: 13px; color: var(--text2);
    border-left: 2px solid transparent;
    transition: all 0.15s;
  }
  .nav-item:hover { color: var(--text); background: var(--bg2); }
  .nav-item.active { color: var(--accent); border-left-color: var(--accent); background: rgba(74,158,255,0.06); }
  .nav-dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex-shrink: 0; }
  .nav-badge {
    margin-left: auto; font-family: var(--mono); font-size: 10px;
    padding: 1px 5px; border-radius: 2px; background: var(--bg3);
    color: var(--text3);
  }
  .nav-badge.red { background: rgba(224,80,96,0.15); color: var(--red); }
  .sidebar-footer {
    padding: 12px 20px; border-top: 1px solid var(--border);
    font-family: var(--mono); font-size: 10px; color: var(--text3);
  }

  /* Main */
  .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
  .topbar {
    height: 48px; min-height: 48px;
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; padding: 0 24px;
    background: var(--bg1); gap: 16px;
  }
  .topbar-title { font-size: 13px; font-weight: 500; color: var(--text); }
  .topbar-sub { font-size: 12px; color: var(--text3); }
  .topbar-right { margin-left: auto; display: flex; gap: 8px; align-items: center; }
  .content { flex: 1; overflow-y: auto; padding: 24px; }

  /* Buttons */
  .btn {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 3px; border: 1px solid var(--border2);
    background: var(--bg2); color: var(--text); font-family: var(--mono);
    font-size: 11px; cursor: pointer; transition: all 0.15s;
    white-space: nowrap;
  }
  .btn:hover { border-color: var(--accent); color: var(--accent); }
  .btn.primary { background: var(--accent2); border-color: var(--accent); color: #fff; }
  .btn.primary:hover { background: var(--accent); }
  .btn.danger { border-color: rgba(224,80,96,0.4); color: var(--red); }
  .btn.danger:hover { background: rgba(224,80,96,0.1); }
  .btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .btn.loading { opacity: 0.7; cursor: wait; }

  /* Cards */
  .card {
    background: var(--bg1); border: 1px solid var(--border);
    border-radius: 4px; padding: 16px;
  }
  .card-title {
    font-family: var(--mono); font-size: 11px; font-weight: 500;
    letter-spacing: 0.08em; text-transform: uppercase; color: var(--text3);
    margin-bottom: 12px;
  }

  /* Stats row */
  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; }
  .stat { background: var(--bg1); border: 1px solid var(--border); border-radius: 4px; padding: 14px 16px; }
  .stat-val { font-family: var(--mono); font-size: 28px; font-weight: 600; color: var(--text); line-height: 1; }
  .stat-val.accent { color: var(--accent); }
  .stat-val.green { color: var(--green); }
  .stat-val.amber { color: var(--amber); }
  .stat-val.red { color: var(--red); }
  .stat-label { font-size: 11px; color: var(--text3); margin-top: 6px; text-transform: uppercase; letter-spacing: 0.06em; }

  /* Decision card — the doc's Decision Output Model */
  .decision-card {
    background: var(--bg1); border: 1px solid var(--border);
    border-radius: 4px; margin-bottom: 12px; overflow: hidden;
  }
  .decision-header {
    padding: 10px 14px; background: var(--bg2);
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 10px;
  }
  .decision-trigger {
    font-family: var(--mono); font-size: 11px; font-weight: 600;
    letter-spacing: 0.06em; color: var(--text);
    flex: 1;
  }
  .decision-body { padding: 0; font-family: var(--mono); font-size: 12px; }
  .decision-section {
    border-bottom: 1px solid var(--border);
    padding: 10px 14px;
  }
  .decision-section:last-child { border-bottom: none; }
  .ds-label {
    font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase;
    color: var(--text3); margin-bottom: 8px; font-weight: 500;
  }
  .ds-row { display: flex; gap: 8px; margin-bottom: 4px; font-size: 11px; }
  .ds-key { color: var(--text3); min-width: 130px; flex-shrink: 0; }
  .ds-val { color: var(--text); }
  .ds-val.accent { color: var(--accent); }
  .ds-val.green { color: var(--green); }
  .ds-val.amber { color: var(--amber); }
  .ds-val.red { color: var(--red); }
  .ds-val.purple { color: var(--purple); }
  .option-row {
    padding: 8px 10px; border-radius: 3px;
    border: 1px solid var(--border); margin-bottom: 6px;
    font-size: 11px;
  }
  .option-row.a { border-color: rgba(74,158,255,0.3); background: rgba(74,158,255,0.04); }
  .option-row.b { border-color: rgba(46,204,138,0.3); background: rgba(46,204,138,0.04); }
  .option-label { color: var(--text3); font-size: 10px; margin-bottom: 3px; }
  .option-text { color: var(--text); }
  .trigger-row { margin-top: 6px; padding: 6px 10px; background: rgba(240,160,48,0.06); border: 1px solid rgba(240,160,48,0.2); border-radius: 3px; font-size: 11px; color: var(--amber); }

  .decision-actions { display: flex; gap: 6px; padding: 10px 14px; background: var(--bg2); border-top: 1px solid var(--border); }

  /* Badges */
  .badge {
    display: inline-flex; align-items: center;
    font-family: var(--mono); font-size: 10px; font-weight: 500;
    padding: 2px 7px; border-radius: 2px;
    text-transform: uppercase; letter-spacing: 0.05em;
  }
  .badge-open { background: rgba(74,158,255,0.12); color: var(--accent); }
  .badge-decided-a { background: rgba(46,204,138,0.12); color: var(--green); }
  .badge-decided-b { background: rgba(46,204,138,0.08); color: #1aaa6a; }
  .badge-deferred { background: rgba(240,160,48,0.12); color: var(--amber); }
  .badge-expired { background: rgba(80,80,100,0.2); color: var(--text3); }
  .badge-emerging { background: rgba(160,106,255,0.1); color: var(--purple); }
  .badge-confirmed { background: rgba(74,158,255,0.1); color: var(--accent); }
  .badge-established { background: rgba(46,204,138,0.1); color: var(--green); }
  .badge-full_reposition { background: rgba(224,80,96,0.12); color: var(--red); }
  .badge-messaging_accent { background: rgba(74,158,255,0.12); color: var(--accent); }
  .badge-framing_shift { background: rgba(160,106,255,0.1); color: var(--purple); }
  .badge-hold_with_trigger { background: rgba(240,160,48,0.12); color: var(--amber); }

  /* Pipeline */
  .pipeline-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .pipeline-step {
    background: var(--bg1); border: 1px solid var(--border);
    border-radius: 4px; padding: 14px;
  }
  .pipeline-step-title { font-family: var(--mono); font-size: 12px; font-weight: 600; color: var(--text); margin-bottom: 4px; }
  .pipeline-step-sub { font-size: 11px; color: var(--text3); margin-bottom: 12px; }
  .pipeline-result {
    font-family: var(--mono); font-size: 11px;
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 3px; padding: 8px 10px; margin-top: 8px;
    color: var(--green); white-space: pre-wrap; max-height: 120px; overflow-y: auto;
  }
  .pipeline-result.err { color: var(--red); }

  /* Signals */
  .signal-row {
    display: flex; align-items: flex-start; gap: 12px;
    padding: 10px 14px; border-bottom: 1px solid var(--border);
    font-size: 12px;
  }
  .signal-row:last-child { border-bottom: none; }
  .signal-source { font-family: var(--mono); font-size: 10px; color: var(--text3); min-width: 80px; padding-top: 2px; }
  .signal-content { color: var(--text); flex: 1; line-height: 1.5; }
  .signal-score { font-family: var(--mono); font-size: 10px; color: var(--text3); min-width: 40px; text-align: right; }
  .signal-tags { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px; }
  .signal-tag { font-family: var(--mono); font-size: 9px; padding: 1px 5px; background: var(--bg3); border-radius: 2px; color: var(--text3); }

  /* Patterns */
  .pattern-row {
    padding: 10px 14px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 12px; font-size: 12px;
  }
  .pattern-row:last-child { border-bottom: none; }
  .pattern-direction { flex: 1; color: var(--text); font-family: var(--mono); font-size: 11px; }
  .pattern-meta { font-size: 10px; color: var(--text3); display: flex; gap: 10px; margin-top: 3px; }

  /* Toast */
  .toast {
    position: fixed; bottom: 20px; right: 20px;
    background: var(--bg2); border: 1px solid var(--border2);
    border-radius: 4px; padding: 10px 16px;
    font-family: var(--mono); font-size: 12px; color: var(--text);
    z-index: 100; animation: slideIn 0.2s ease;
  }
  .toast.ok { border-left: 3px solid var(--green); }
  .toast.err { border-left: 3px solid var(--red); }
  @keyframes slideIn { from { transform: translateX(20px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

  .divider { border: none; border-top: 1px solid var(--border); margin: 16px 0; }
  .empty { color: var(--text3); font-family: var(--mono); font-size: 12px; padding: 24px; text-align: center; }
  .section-title { font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text3); margin-bottom: 12px; margin-top: 20px; }
  .section-title:first-child { margin-top: 0; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .scroll-list { background: var(--bg1); border: 1px solid var(--border); border-radius: 4px; overflow: hidden; }
`;

// ── Helpers ───────────────────────────────────────────────────────────────────

function Badge({ status }) {
  const s = (status || "").toLowerCase().replace(/ /g, "_");
  return <span className={`badge badge-${s}`}>{status}</span>;
}

function Stat({ val, label, color }) {
  return (
    <div className="stat">
      <div className={`stat-val ${color || ""}`}>{val ?? "—"}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

function useToast() {
  const [toast, setToast] = useState(null);
  const show = (msg, type = "ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };
  return [toast, show];
}

function urgencyColor(u) {
  if (u === "high") return "red";
  if (u === "medium") return "amber";
  return "green";
}

function daysColor(d) {
  if (d < 0) return "red";
  if (d <= 5) return "amber";
  return "green";
}

// ── Decision Card — implements doc's Decision Output Model format ─────────────
function DecisionCard({ d, onAction }) {
  const [acting, setActing] = useState(false);

  const act = async (status) => {
    setActing(true);
    await call("POST", `/decisions/${d.id}/status?status=${status}`);
    onAction();
    setActing(false);
  };

  const daysLeft = (() => {
    const cb = new Date(d.commit_by);
    const today = new Date();
    return Math.round((cb - today) / 86400000);
  })();

  return (
    <div className="decision-card">
      <div className="decision-header">
        <span className="decision-trigger">
          DECISION TRIGGER: axis_shift — {d.signal?.split("→")[0]?.trim()?.slice(0, 60)}
        </span>
        <Badge status={d.status} />
      </div>

      <div className="decision-body">
        {/* Signal basis */}
        <div className="decision-section">
          <div className="ds-label">Signal basis</div>
          <div className="ds-row"><span className="ds-key">Signal tier</span><span className="ds-val accent">EMERGING</span></div>
          <div className="ds-row"><span className="ds-key">Independence score</span><span className="ds-val">LOW — press only (0.5×)</span></div>
          <div className="ds-row"><span className="ds-key">Direction</span><span className="ds-val" style={{wordBreak:"break-word"}}>{d.signal}</span></div>
        </div>

        {/* Context */}
        <div className="decision-section">
          <div className="ds-label">Context</div>
          <div className="ds-row"><span className="ds-key">Decision type</span><Badge status={d.decision_type?.replace(/_/g," ")} /></div>
          <div className="ds-row"><span className="ds-key">Urgency</span><span className={`ds-val ${urgencyColor(d.urgency)}`}>{d.urgency?.toUpperCase()}</span></div>
          <div className="ds-row"><span className="ds-key">Time horizon</span><span className="ds-val">{d.time_horizon?.toUpperCase()}</span></div>
          <div className="ds-row"><span className="ds-key">Commit by</span><span className={`ds-val ${daysColor(daysLeft)}`}>{d.commit_by} ({daysLeft >= 0 ? `${daysLeft}d remaining` : `${Math.abs(daysLeft)}d OVERDUE`})</span></div>
          <div className="ds-row"><span className="ds-key">Decision owner</span><span className="ds-val">{d.decision_owner}</span></div>
        </div>

        {/* The decision */}
        <div className="decision-section">
          <div className="ds-label">The decision</div>
          <div className="option-row a">
            <div className="option-label">A) TAKE ACTION</div>
            <div className="option-text">{d.option_a}</div>
          </div>
          <div className="option-row b">
            <div className="option-label">B) ALTERNATIVE / HOLD</div>
            <div className="option-text">{d.option_b}</div>
          </div>
          {d.b_trigger && (
            <div className="trigger-row">↳ Re-evaluate if: {d.b_trigger}</div>
          )}
        </div>

        {/* Impact */}
        {d.impact && (
          <div className="decision-section">
            <div className="ds-label">Impact if no decision made</div>
            <div style={{fontSize:11, color:"var(--text)", lineHeight:1.5}}>{d.impact}</div>
          </div>
        )}

        {/* Outcome log */}
        <div className="decision-section">
          <div className="ds-label">Outcome log</div>
          <div className="ds-row"><span className="ds-key">Status</span><span className="ds-val">[ {d.status} ]</span></div>
          <div className="ds-row"><span className="ds-key">Date decided</span><span className="ds-val">{d.decided_at ? d.decided_at.slice(0,10) : "___________"}</span></div>
          <div className="ds-row"><span className="ds-key">30-day review</span><span className="ds-val">{d.review_30d ? `[x] ${d.review_30d}` : "[ ] Accurate  [ ] Inaccurate  [ ] Inconclusive"}</span></div>
        </div>
      </div>

      {d.status === "OPEN" && (
        <div className="decision-actions">
          <button className="btn primary" disabled={acting} onClick={() => act("DECIDED-A")}>Decide A</button>
          <button className="btn" disabled={acting} onClick={() => act("DECIDED-B")}>Decide B</button>
          <button className="btn danger" disabled={acting} onClick={() => act("DEFERRED")}>Defer</button>
        </div>
      )}
    </div>
  );
}

// ── Views ─────────────────────────────────────────────────────────────────────

function Dashboard({ health, slaStatus, outcomes, reload }) {
  const open = slaStatus.filter(s => s.status === "OPEN").length;
  const deferred = slaStatus.filter(s => s.status === "DEFERRED").length;
  const overdue = slaStatus.filter(s => s.is_overdue).length;

  return (
    <>
      <div className="stats">
        <Stat val={health?.signal_count ?? "—"} label="Signals collected" color="accent" />
        <Stat val={open} label="Open decisions" color="green" />
        <Stat val={deferred} label="Deferred" color="amber" />
        <Stat val={outcomes?.model_suspension_risk ? "YES" : "NO"} label="Suspension risk" color={outcomes?.model_suspension_risk ? "red" : "green"} />
      </div>

      <div className="section-title">SLA overview</div>
      <div className="scroll-list">
        {slaStatus.length === 0 && <div className="empty">No active decisions</div>}
        {slaStatus.map(d => (
          <div key={d.decision_id} className="signal-row" style={{alignItems:"center"}}>
            <div style={{flex:1}}>
              <div style={{fontFamily:"var(--mono)", fontSize:11, color:"var(--text)", marginBottom:3}}>{d.signal}</div>
              <div style={{fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)"}}>Owner: {d.decision_owner} · Type: {d.decision_type}</div>
            </div>
            <div style={{textAlign:"right", flexShrink:0}}>
              <div style={{fontFamily:"var(--mono)", fontSize:11, color:`var(--${daysColor(d.days_remaining)})`}}>
                {d.is_overdue ? `${Math.abs(d.days_remaining)}d overdue` : `${d.days_remaining}d left`}
              </div>
              <div style={{marginTop:3}}><Badge status={d.status} /></div>
            </div>
          </div>
        ))}
      </div>

      <div className="section-title" style={{marginTop:20}}>Outcome accuracy</div>
      <div className="grid2">
        <div className="card">
          <div className="card-title">30-day window</div>
          <div className="ds-row"><span className="ds-key">Reviewed</span><span className="ds-val">{outcomes?.reviewed_30d ?? 0}</span></div>
          <div className="ds-row"><span className="ds-key">Accurate</span><span className="ds-val green">{outcomes?.accurate_30d ?? 0}</span></div>
          <div className="ds-row"><span className="ds-key">Inaccurate</span><span className="ds-val red">{outcomes?.inaccurate_30d ?? 0}</span></div>
        </div>
        <div className="card">
          <div className="card-title">90-day window (suspension threshold &gt;40%)</div>
          <div className="ds-row"><span className="ds-key">Reviewed</span><span className="ds-val">{outcomes?.reviewed_90d ?? 0}</span></div>
          <div className="ds-row"><span className="ds-key">Inaccuracy rate</span><span className={`ds-val ${outcomes?.model_suspension_risk ? "red" : "green"}`}>{outcomes?.inaccuracy_rate_90d != null ? `${(outcomes.inaccuracy_rate_90d * 100).toFixed(0)}%` : "—"}</span></div>
          <div className="ds-row"><span className="ds-key">Model status</span><span className={`ds-val ${outcomes?.model_suspension_risk ? "red" : "green"}`}>{outcomes?.model_suspension_risk ? "⚠ SUSPENSION RISK" : "ACTIVE"}</span></div>
        </div>
      </div>
    </>
  );
}

function Decisions({ reload }) {
  const [decisions, setDecisions] = useState([]);
  const [filter, setFilter] = useState("OPEN");
  const [toast, showToast] = useToast();

  const load = useCallback(async () => {
    const d = await get(filter ? `/decisions?status=${filter}` : "/decisions");
    if (!d._error) setDecisions(Array.isArray(d) ? d : []);
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const onAction = () => { load(); reload(); };

  return (
    <>
      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
      <div style={{display:"flex", gap:6, marginBottom:16, flexWrap:"wrap"}}>
        {["OPEN","DECIDED-A","DECIDED-B","DEFERRED","EXPIRED",""].map(s => (
          <button key={s} className={`btn ${filter === s ? "primary" : ""}`} onClick={() => setFilter(s)}>{s || "ALL"}</button>
        ))}
      </div>
      {decisions.length === 0 && <div className="empty">No decisions with status: {filter || "ALL"}</div>}
      {decisions.map(d => <DecisionCard key={d.id} d={d} onAction={onAction} />)}
    </>
  );
}

function Patterns({ reload }) {
  const [patterns, setPatterns] = useState([]);
  const [toast, showToast] = useToast();

  const load = async () => {
    const d = await get("/patterns");
    if (!d._error) setPatterns(Array.isArray(d) ? d : []);
  };
  useEffect(() => { load(); }, []);

  const review = async (id) => {
    const r = await post(`/patterns/${id}/review`);
    if (!r._error) { showToast("Pattern marked reviewed"); load(); reload(); }
    else showToast(r._error, "err");
  };

  return (
    <>
      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
      <div style={{marginBottom:8, fontFamily:"var(--mono)", fontSize:11, color:"var(--text3)"}}>
        {patterns.length} patterns · {patterns.filter(p => !p.reviewed).length} pending review
      </div>
      <div className="scroll-list">
        {patterns.length === 0 && <div className="empty">No patterns. Run cluster to generate.</div>}
        {patterns.map(p => (
          <div key={p.id} className="pattern-row">
            <div style={{flex:1}}>
              <div className="pattern-direction">{p.direction}</div>
              <div className="pattern-meta">
                <span>{p.signal_tier}</span>
                <span>{p.source_count} source cats</span>
                <span>{p.signal_ids?.length ?? 0} signals</span>
                <span>{p.created_at?.slice(0,10)}</span>
              </div>
            </div>
            <Badge status={p.signal_tier} />
            {p.reviewed
              ? <span style={{fontFamily:"var(--mono)", fontSize:10, color:"var(--green)"}}>reviewed</span>
              : <button className="btn" onClick={() => review(p.id)}>Review</button>
            }
          </div>
        ))}
      </div>
    </>
  );
}

function Signals() {
  const [signals, setSignals] = useState([]);
  const [limit, setLimit] = useState(20);

  const load = async () => {
    const d = await get(`/signals/recent?limit=${limit}`);
    if (!d._error) setSignals(Array.isArray(d) ? d : []);
  };
  useEffect(() => { load(); }, [limit]);

  return (
    <>
      <div style={{display:"flex", gap:6, marginBottom:16, alignItems:"center"}}>
        {[20, 50, 100].map(n => (
          <button key={n} className={`btn ${limit === n ? "primary" : ""}`} onClick={() => setLimit(n)}>{n}</button>
        ))}
        <span style={{fontFamily:"var(--mono)", fontSize:11, color:"var(--text3)", marginLeft:8}}>{signals.length} signals shown</span>
        <button className="btn" style={{marginLeft:"auto"}} onClick={load}>Refresh</button>
      </div>
      <div className="scroll-list">
        {signals.length === 0 && <div className="empty">No signals. Run ingest first.</div>}
        {signals.map(s => (
          <div key={s.id} className="signal-row">
            <div className="signal-source">{s.source}<br /><span style={{color:"var(--text3)", fontSize:9}}>{s.source_family?.slice(0,14)}</span></div>
            <div style={{flex:1}}>
              <div className="signal-content">{s.content?.slice(0,160)}{s.content?.length > 160 ? "…" : ""}</div>
              <div className="signal-tags">
                {(Array.isArray(s.tags) ? s.tags : []).map(t => <span key={t} className="signal-tag">{t}</span>)}
              </div>
            </div>
            <div className="signal-score">{Number(s.weighted_score).toFixed(2)}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function Pipeline({ reload }) {
  const [results, setResults] = useState({});
  const [loading, setLoading] = useState({});
  const [toast, showToast] = useToast();

  const run = async (key, path, label) => {
    setLoading(l => ({...l, [key]: true}));
    const r = await post(path);
    setLoading(l => ({...l, [key]: false}));
    if (r._error) {
      setResults(rs => ({...rs, [key]: `ERROR: ${r._error}`}));
      showToast(`${label} failed`, "err");
    } else {
      setResults(rs => ({...rs, [key]: JSON.stringify(r, null, 2)}));
      showToast(`${label} complete`);
      reload();
    }
  };

  const steps = [
    { key:"rss", path:"/ingest/rss", label:"Ingest RSS", sub:"Analyst + press feeds" },
    { key:"comp", path:"/ingest/competitor", label:"Ingest Competitor", sub:"10 sources · CSS-selector scrape" },
    { key:"embed", path:"/embed", label:"Embed Signals", sub:"SBERT all-MiniLM-L6-v2 → Weaviate" },
    { key:"cluster", path:"/cluster", label:"Cluster", sub:"UMAP → HDBSCAN → BERTopic" },
    { key:"interpret", path:"/interpret", label:"Interpret", sub:"4-prompt LLM pipeline → decisions" },
    { key:"stage5", path:"/stage5", label:"Run Stage 5", sub:"SLA enforcement + tier upgrades" },
  ];

  return (
    <>
      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
      <div style={{marginBottom:16, display:"flex", gap:8}}>
        <button className="btn primary" onClick={async () => {
          for (const s of steps) await run(s.key, s.path, s.label);
        }}>Run full pipeline</button>
      </div>
      <div className="pipeline-grid">
        {steps.map(s => (
          <div key={s.key} className="pipeline-step">
            <div className="pipeline-step-title">{s.label}</div>
            <div className="pipeline-step-sub">{s.sub}</div>
            <button
              className={`btn ${loading[s.key] ? "loading" : ""}`}
              disabled={loading[s.key]}
              onClick={() => run(s.key, s.path, s.label)}
            >
              {loading[s.key] ? "running…" : "Run"}
            </button>
            {results[s.key] && (
              <div className={`pipeline-result ${results[s.key].startsWith("ERROR") ? "err" : ""}`}>
                {results[s.key]}
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  );
}

// ── App shell ─────────────────────────────────────────────────────────────────

const VIEWS = [
  { id:"dashboard", label:"Dashboard" },
  { id:"decisions", label:"Decisions" },
  { id:"patterns", label:"Patterns" },
  { id:"signals", label:"Signals" },
  { id:"pipeline", label:"Pipeline" },
];

export default function App() {
  const [view, setView] = useState("dashboard");
  const [health, setHealth] = useState(null);
  const [slaStatus, setSlaStatus] = useState([]);
  const [outcomes, setOutcomes] = useState({});
  const [deferred, setDeferred] = useState([]);

  const reload = useCallback(async () => {
    const [h, s, o, df] = await Promise.all([
      get("/health"), get("/sla/status"), get("/outcomes"), get("/deferred")
    ]);
    if (!h._error) setHealth(h);
    if (!s._error) setSlaStatus(Array.isArray(s) ? s : []);
    if (!o._error) setOutcomes(o);
    if (!df._error) setDeferred(Array.isArray(df) ? df : []);
  }, []);

  useEffect(() => { reload(); }, [reload]);

  const openCount = slaStatus.filter(s => s.status === "OPEN").length;
  const deferredCount = deferred.length;

  return (
    <>
      <style>{css}</style>
      <div className="app">
        <aside className="sidebar">
          <div className="sidebar-logo">
            <div className="logo-name">PRISM</div>
            <div className="logo-sub">Decision Intelligence Agent</div>
          </div>
          <nav className="nav">
            {VIEWS.map(v => (
              <div
                key={v.id}
                className={`nav-item ${view === v.id ? "active" : ""}`}
                onClick={() => setView(v.id)}
              >
                <span className="nav-dot" />
                {v.label}
                {v.id === "decisions" && openCount > 0 &&
                  <span className="nav-badge">{openCount}</span>}
                {v.id === "dashboard" && deferredCount > 0 &&
                  <span className="nav-badge red">{deferredCount} def</span>}
              </div>
            ))}
          </nav>
          <div className="sidebar-footer">
            <div>{health ? `api: ${health.api}` : "connecting…"}</div>
            <div style={{marginTop:3}}>{health ? `signals: ${health.signal_count}` : ""}</div>
            <div style={{marginTop:3}}>{health?.llm_provider ? `llm: ${health.llm_provider}` : ""}</div>
          </div>
        </aside>

        <div className="main">
          <div className="topbar">
            <span className="topbar-title">{VIEWS.find(v => v.id === view)?.label}</span>
            <span className="topbar-sub">FlashSystem EMEA · PMM DIA V1</span>
            <div className="topbar-right">
              <button className="btn" onClick={reload}>Refresh</button>
            </div>
          </div>
          <div className="content">
            {view === "dashboard" && <Dashboard health={health} slaStatus={slaStatus} outcomes={outcomes} reload={reload} />}
            {view === "decisions" && <Decisions reload={reload} />}
            {view === "patterns" && <Patterns reload={reload} />}
            {view === "signals" && <Signals />}
            {view === "pipeline" && <Pipeline reload={reload} />}
          </div>
        </div>
      </div>
    </>
  );
}
