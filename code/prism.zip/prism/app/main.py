"""Prism DIA — API spine.

Boots the stack and exposes health + a Layer 2 scoring endpoint so you can
verify the signal-quality engine end-to-end before wiring ingestion.
"""
import json
import os
from datetime import datetime
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import pathlib
from pydantic import BaseModel
import yaml

from layers.signal_quality import score_signal, assign_tier
from layers.embedding import embed_pending, semantic_search
from layers.clustering import run_clustering, get_patterns, mark_reviewed, delete_pattern
from layers.stage4 import run_interpretation, get_decisions, update_decision_status
from layers.stage5 import run_stage5, run_sla_enforcement, get_sla_status, record_outcome, get_outcome_summary, run_tier_upgrades
from ingest.competitor import collect_competitor, collect_peerspot
from ingest.rss import collect_rss

app = FastAPI(title="Prism DIA", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_gui = pathlib.Path("/app/gui")
if _gui.exists():
    app.mount("/gui", StaticFiles(directory=str(_gui), html=True), name="gui")

@app.get("/")
def root():
    gui_index = pathlib.Path("/app/gui/index.html")
    if gui_index.exists():
        return FileResponse(str(gui_index))
    return {"api": "Prism DIA", "version": "0.1.0", "gui": "/gui"}


# Pooled connections — context manager, commits on clean exit
from db.pool import connection as pg


@app.get("/health")
def health():
    out = {"api": "ok", "llm_provider": os.getenv("LLM_PROVIDER", "ollama")}
    try:
        with pg() as conn, conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM signal;")
            out["postgres"] = "ok"
            out["signal_count"] = cur.fetchone()[0]
    except Exception as e:
        out["postgres"] = f"error: {e}"
    # Ollama liveness — hit the tags endpoint, expect 200
    try:
        import httpx as _httpx
        ollama_url = os.getenv("OLLAMA_BASE_URL", "http://192.168.1.121:11434")
        r = _httpx.get(f"{ollama_url}/api/tags", timeout=3.0)
        out["ollama"] = "ok" if r.status_code == 200 else f"error: HTTP {r.status_code}"
    except Exception as e:
        out["ollama"] = f"error: {e}"
    return out


class SignalIn(BaseModel):
    source: str
    source_family: str
    timestamp: datetime


class TierIn(BaseModel):
    signals: list[SignalIn]


@app.post("/score")
def score(sig: SignalIn):
    return score_signal(sig.source, sig.timestamp)


@app.post("/tier")
def tier(payload: TierIn):
    rows = [s.model_dump() for s in payload.signals]
    r = assign_tier(rows)
    return {
        "tier": r.tier,
        "weighted_count": round(r.weighted_count, 3),
        "source_categories": r.source_categories,
        "action": r.action,
    }


@app.post("/ingest/competitor")
def ingest_competitor():
    return collect_competitor()


@app.post("/ingest/peerspot")
def ingest_peerspot():
    """Collect PeerSpot reviews — field-equivalent signals at 1.0x weight."""
    return collect_peerspot()


@app.post("/ingest/rss")
def ingest_rss():
    return collect_rss()


@app.get("/signals/recent")
def recent_signals(
    limit: int = 25,
    source: str | None = None,
    search: str | None = None,
):
    with pg() as conn, conn.cursor() as cur:
        base = """SELECT id, source, source_family, timestamp,
                         content, entities, tags,
                         independence_wt, recency_wt, weighted_score
                  FROM signal"""
        conditions, params = [], []
        if source:
            conditions.append("source = %s")
            params.append(source)
        if search:
            conditions.append("content ILIKE %s")
            params.append(f"%{search}%")
        if conditions:
            base += " WHERE " + " AND ".join(conditions)
        base += " ORDER BY timestamp DESC LIMIT %s"
        params.append(limit)
        cur.execute(base, params)
        cols = [d[0] for d in cur.description]
        rows = []
        for row in cur.fetchall():
            d = dict(zip(cols, row))
            # Parse JSON arrays stored as strings
            for field in ("entities", "tags"):
                if isinstance(d.get(field), str):
                    try:
                        d[field] = json.loads(d[field])
                    except Exception:
                        d[field] = []
            # Serialise timestamp
            if hasattr(d.get("timestamp"), "isoformat"):
                d["timestamp"] = d["timestamp"].isoformat()
            rows.append(d)
        return rows


@app.get("/signals/stats")
def signal_stats():
    """Corpus breakdown by source — counts, avg score, newest timestamp."""
    with pg() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT source,
                      COUNT(*)                              AS count,
                      ROUND(AVG(weighted_score)::numeric,3) AS avg_score,
                      MAX(timestamp)                        AS newest,
                      COUNT(*) FILTER (WHERE recency_wt = 0) AS archived
               FROM signal
               GROUP BY source
               ORDER BY avg_score DESC;"""
        )
        cols = [d[0] for d in cur.description]
        rows = []
        for row in cur.fetchall():
            d = dict(zip(cols, row))
            if hasattr(d.get("newest"), "isoformat"):
                d["newest"] = d["newest"].isoformat()
            rows.append(d)
        return rows


# ── Stage 3: Embedding + Clustering ───────────────────────────────────────────

@app.post("/embed")
def embed():
    """Embed all unembedded signals into Weaviate."""
    return embed_pending()


@app.post("/cluster")
def cluster():
    """Run UMAP → HDBSCAN → BERTopic clustering on embedded signals."""
    return run_clustering()


@app.get("/patterns")
def patterns(reviewed_only: bool = False):
    """List pattern objects. reviewed_only=true filters to post-calibration patterns."""
    rows = get_patterns(reviewed_only=reviewed_only)
    # convert datetime to string for JSON
    for r in rows:
        if hasattr(r.get("created_at"), "isoformat"):
            r["created_at"] = r["created_at"].isoformat()
    return rows


@app.post("/patterns/{pattern_id}/review")
def review_pattern(pattern_id: str):
    """Mark a pattern as reviewed — lifts it past the calibration gate."""
    ok = mark_reviewed(pattern_id)
    return {"pattern_id": pattern_id, "reviewed": ok}


@app.delete("/patterns/{pattern_id}")
def discard_pattern(pattern_id: str):
    """Permanently delete a junk pattern. Signals are preserved — next cluster run
    may form a cleaner cluster from them. Use this to remove noise patterns."""
    ok = delete_pattern(pattern_id)
    return {"pattern_id": pattern_id, "deleted": ok}


@app.get("/search")
def search(q: str, limit: int = 10):
    """Semantic search over embedded signals."""
    return semantic_search(q, limit=limit)


# ── Stage 4: Interpretation + Decisions ───────────────────────────────────────

@app.post("/interpret")
def interpret(force: bool = False):
    """Run four-prompt interpretation on all reviewed patterns → write decisions."""
    return run_interpretation(force=force)


@app.get("/decisions")
def decisions(status: str | None = None):
    """List decisions. Filter by status: OPEN|DECIDED-A|DECIDED-B|DEFERRED|EXPIRED"""
    return get_decisions(status=status)


@app.post("/decisions/{decision_id}/status")
def decision_status(decision_id: str, status: str, notes: str = ""):
    """Update a decision status (OPEN→DECIDED-A/B, DEFERRED, EXPIRED)."""
    ok = update_decision_status(decision_id, status, notes)
    return {"decision_id": decision_id, "updated": ok}


@app.get("/deferred")
def deferred():
    """Decisions past commit_by with no logged response — the DEFERRED surface."""
    with pg() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, model, decision_owner, commit_by, status FROM v_deferred;")
        cols = [d[0] for d in cur.description]
        rows = []
        for row in cur.fetchall():
            d = dict(zip(cols, row))
            if hasattr(d.get("commit_by"), "isoformat"):
                d["commit_by"] = d["commit_by"].isoformat()
            rows.append(d)
        return rows


# ── Stage 5: Decision model + SLA enforcement ─────────────────────────────────

@app.post("/sla/enforce")
def sla_enforce():
    """Run SLA enforcement: auto-DEFERRED overdue, EXPIRE stale, flag warnings."""
    return run_sla_enforcement()


@app.get("/sla/status")
def sla_status():
    """Full SLA status report for all active decisions."""
    return get_sla_status()


@app.post("/tiers/upgrade")
def tier_upgrade():
    """Re-evaluate pattern signal tiers and bump decision urgency if tier upgraded."""
    return run_tier_upgrades()


@app.post("/stage5")
def stage5():
    """Run full Stage 5: SLA enforcement + tier upgrades + outcome summary."""
    return run_stage5()


@app.post("/decisions/{decision_id}/outcome")
def decision_outcome(decision_id: str, review_period: int, outcome: str, notes: str = ""):
    """Record 30/60/90-day outcome review (accurate|inaccurate|inconclusive)."""
    return record_outcome(decision_id, review_period, outcome, notes)


@app.get("/outcomes")
def outcomes():
    """Aggregate outcome accuracy — includes model suspension risk flag."""
    return get_outcome_summary()


# ── GUI extensions: undo, notes, next steps, option C ────────────────────────

@app.post("/decisions/{decision_id}/undo")
def undo_decision(decision_id: str):
    """Revert a decided/deferred decision back to OPEN."""
    with pg() as conn, conn.cursor() as cur:
        cur.execute(
            """UPDATE decision SET status='OPEN', decided_at=NULL
               WHERE id=%s AND status != 'EXPIRED'
               RETURNING id, status;""",
            (decision_id,)
        )
        row = cur.fetchone()
        conn.commit()
    return {"decision_id": decision_id, "reverted": row is not None, "status": "OPEN" if row else None}


@app.post("/decisions/{decision_id}/notes")
def update_notes(decision_id: str, notes: str = "", next_steps: str = ""):
    """Update notes and next steps on a decision."""
    with pg() as conn, conn.cursor() as cur:
        # next_steps stored in b_trigger field if not HOLD (reuse, or store in notes suffix)
        combined = notes
        if next_steps:
            combined = notes + ("||NEXT_STEPS||" + next_steps if notes else "NEXT_STEPS_ONLY||" + next_steps)
        cur.execute(
            "UPDATE decision SET notes=%s WHERE id=%s RETURNING id;",
            (combined, decision_id)
        )
        found = cur.fetchone() is not None
        conn.commit()
    return {"decision_id": decision_id, "updated": found}


@app.post("/decisions/{decision_id}/choose-c")
def choose_c(decision_id: str, option_c: str, notes: str = ""):
    """Log a custom Option C decision — an alternative path not in A or B."""
    from datetime import datetime, timezone
    with pg() as conn, conn.cursor() as cur:
        cur.execute(
            """UPDATE decision
               SET status='DECIDED-A', decided_at=%s,
                   notes=%s
               WHERE id=%s RETURNING id;""",
            (datetime.now(timezone.utc), f"OPTION-C: {option_c}" + (f" | Notes: {notes}" if notes else ""), decision_id)
        )
        found = cur.fetchone() is not None
        conn.commit()
    return {"decision_id": decision_id, "option_c": option_c, "logged": found}


# ── Admin utilities ───────────────────────────────────────────────────────────

@app.post("/admin/reset-patterns")
def reset_patterns():
    """Delete all patterns and constraint_breaks so clustering can produce a
    fresh set. NEVER touches decisions — those are preserved.

    Use this after:
    - Deleting duplicate signals and rebuilding Weaviate
    - A major corpus change where old clusters are no longer valid
    """
    with pg() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM constraint_break;")
        cb = cur.rowcount
        cur.execute("DELETE FROM pattern;")
        p = cur.rowcount
        conn.commit()
    return {
        "constraint_breaks_deleted": cb,
        "patterns_deleted": p,
        "decisions_preserved": True,
        "next_step": "POST /cluster",
    }

# ── Assumptions Management ────────────────────────────────────────────────────

@app.get("/assumptions")
def get_assumptions():
    """Get all assumptions from the YAML file, including inactive (commented) ones."""
    import yaml
    import re
    from datetime import date
    
    config_path = pathlib.Path("/app/config/positioning_assumptions.yaml")
    if not config_path.exists():
        return {"active": [], "inactive": []}
    
    with open(config_path, 'r') as f:
        content = f.read()
    
    # Parse active assumptions
    try:
        data = yaml.safe_load(content)
        active = data.get('assumptions', [])
    except:
        active = []
    
    # Parse inactive (commented) assumptions
    inactive = []
    lines = content.split('\n')
    in_commented_block = False
    current_assumption = {}
    deleted_date = None
    
    for line in lines:
        # Check for deletion marker
        if '# DELETED:' in line:
            match = re.search(r'# DELETED:\s*(\d{4}-\d{2}-\d{2})', line)
            if match:
                deleted_date = match.group(1)
                in_commented_block = True
                current_assumption = {'deleted_date': deleted_date}
                continue
        
        if in_commented_block and line.strip().startswith('#'):
            # Remove leading # and whitespace
            clean_line = line.strip()[1:].strip()
            
            if clean_line.startswith('id:'):
                current_assumption['id'] = clean_line.split(':', 1)[1].strip()
            elif clean_line.startswith('statement:'):
                current_assumption['statement'] = clean_line.split(':', 1)[1].strip().strip('"')
            elif clean_line.startswith('affected_area:'):
                current_assumption['affected_area'] = clean_line.split(':', 1)[1].strip()
            elif clean_line.startswith('date_encoded:'):
                current_assumption['date_encoded'] = clean_line.split(':', 1)[1].strip().strip('"')
            elif clean_line.startswith('last_reviewed:'):
                current_assumption['last_reviewed'] = clean_line.split(':', 1)[1].strip().strip('"')
            elif clean_line.startswith('owner:'):
                current_assumption['owner'] = clean_line.split(':', 1)[1].strip().strip('"')
        elif in_commented_block and not line.strip().startswith('#'):
            # End of commented block
            if current_assumption.get('id'):
                inactive.append(current_assumption)
            in_commented_block = False
            current_assumption = {}
            deleted_date = None
    
    # Sort inactive by deleted_date (most recent first)
    inactive.sort(key=lambda x: x.get('deleted_date', ''), reverse=True)
    
    return {"active": active, "inactive": inactive}


def _yaml_dquote(s: str) -> str:
    """Escape a value for a YAML double-quoted scalar."""
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def _find_changelog_idx(lines: list[str]):
    for idx, l in enumerate(lines):
        if l.strip().startswith("# ── Change Log"):
            return idx
    return None


def _write_config_snapshot():
    """Write current configuration state to Prism-config.md in the root directory.
    
    This captures both products (from localStorage in frontend) and assumptions
    (from YAML file) to provide a markdown snapshot of the current configuration.
    """
    config_md_path = pathlib.Path("/app/Prism-config.md")
    
    # Read assumptions from YAML
    assumptions_path = pathlib.Path("/app/config/positioning_assumptions.yaml")
    assumptions_data = {"active": [], "inactive": []}
    
    if assumptions_path.exists():
        try:
            with open(assumptions_path, 'r') as f:
                content = f.read()
                data = yaml.safe_load(content)
                assumptions_data["active"] = data.get('assumptions', [])
        except Exception:
            pass
    
    # Build markdown content
    lines = [
        "# Prism Configuration Snapshot\n",
        "\n",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n",
        "\n",
        "---\n",
        "\n",
        "## Products and Offerings\n",
        "\n",
        "*Note: Products are stored in browser localStorage and may vary by user/browser.*\n",
        "\n",
        "To view current products, access the Configuration tab in the Prism GUI.\n",
        "\n",
        "---\n",
        "\n",
        "## Positioning Assumptions\n",
        "\n",
    ]
    
    if assumptions_data["active"]:
        lines.append("### Active Assumptions\n\n")
        for assumption in assumptions_data["active"]:
            lines.append(f"**{assumption.get('id', 'N/A')}**\n\n")
            lines.append(f"- **Statement:** {assumption.get('statement', 'N/A')}\n")
            lines.append(f"- **Affected Area:** {assumption.get('affected_area', 'N/A')}\n")
            lines.append(f"- **Owner:** {assumption.get('owner', 'N/A')}\n")
            lines.append(f"- **Date Encoded:** {assumption.get('date_encoded', 'N/A')}\n")
            lines.append(f"- **Last Reviewed:** {assumption.get('last_reviewed', 'N/A')}\n")
            lines.append("\n")
    else:
        lines.append("*No active assumptions configured.*\n\n")
    
    lines.append("---\n\n")
    lines.append("*This file is auto-generated when configuration changes are made.*\n")
    
    # Write to file
    with open(config_md_path, 'w') as f:
        f.writelines(lines)
    
    return str(config_md_path)


@app.post("/assumptions")
def create_assumption(statement: str, affected_area: str, owner: str):
    """Add a new assumption to the YAML file.

    Preserves the header comments, the `meta:` block, and the change-log —
    the previous implementation round-tripped through yaml.safe_load()/
    yaml.dump(), which silently drops all comments. This version only
    inserts the new block as raw text; everything else is untouched
    byte-for-byte.
    """
    import yaml
    from datetime import date

    config_path = pathlib.Path("/app/config/positioning_assumptions.yaml")

    with open(config_path, 'r') as f:
        content = f.read()
    data = yaml.safe_load(content) or {}

    # Find next ID number (read-only — this parsed structure is never written back)
    existing_ids = [a['id'] for a in data.get('assumptions', [])]
    max_num = 0
    for aid in existing_ids:
        if aid.startswith('ASSUME-'):
            try:
                max_num = max(max_num, int(aid.split('-')[1]))
            except Exception:
                pass

    new_id = f"ASSUME-{str(max_num + 1).zfill(3)}"
    today = date.today().isoformat()

    new_assumption = {
        'id': new_id,
        'statement': statement,
        'affected_area': affected_area,
        'date_encoded': today,
        'last_reviewed': today,
        'owner': owner,
    }

    block_lines = [
        f'  - id: {new_id}\n',
        f'    statement: "{_yaml_dquote(statement)}"\n',
        f'    affected_area: {affected_area}\n',
        f'    date_encoded: "{today}"\n',
        f'    last_reviewed: "{today}"\n',
        f'    owner: "{_yaml_dquote(owner)}"\n',
        '\n',
    ]
    excerpt = statement[:60] + ("..." if len(statement) > 60 else "")
    log_line = f'# {today}  {new_id} added: "{_yaml_dquote(excerpt)}"  — {owner}\n'

    lines = content.splitlines(keepends=True)
    changelog_idx = _find_changelog_idx(lines)

    if changelog_idx is not None:
        new_lines = lines[:changelog_idx] + block_lines + lines[changelog_idx:]
    else:
        new_lines = lines + block_lines + [
            '# ── Change Log (required: one entry per edit) ─────────\n',
        ]
    new_lines.append(log_line)

    with open(config_path, 'w') as f:
        f.writelines(new_lines)

    # Write configuration snapshot
    _write_config_snapshot()

    return {"success": True, "assumption": new_assumption}


@app.put("/assumptions/{assumption_id}")
def update_assumption(assumption_id: str, statement: str, affected_area: str, owner: str):
    """Update an existing assumption in place.

    Preserves the header comments, the `meta:` block, and the change-log —
    only the target block's editable fields (statement, affected_area,
    owner, last_reviewed) are rewritten as raw text.
    """
    from datetime import date

    config_path = pathlib.Path("/app/config/positioning_assumptions.yaml")

    with open(config_path, 'r') as f:
        lines = f.readlines()

    today = date.today().isoformat()
    found = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if f'id: {assumption_id}' in line or f'id: "{assumption_id}"' in line:
            found = True
            block_start = i
            j = i + 1
            while j < len(lines) and lines[j].startswith('    ') and ':' in lines[j]:
                j += 1
            block_end = j  # exclusive

            for k in range(block_start, block_end):
                stripped = lines[k].strip()
                if stripped.startswith('statement:'):
                    lines[k] = f'    statement: "{_yaml_dquote(statement)}"\n'
                elif stripped.startswith('affected_area:'):
                    lines[k] = f'    affected_area: {affected_area}\n'
                elif stripped.startswith('owner:'):
                    lines[k] = f'    owner: "{_yaml_dquote(owner)}"\n'
                elif stripped.startswith('last_reviewed:'):
                    lines[k] = f'    last_reviewed: "{today}"\n'
            break
        i += 1

    if not found:
        return {"success": False, "error": "Assumption not found"}

    excerpt = statement[:60] + ("..." if len(statement) > 60 else "")
    log_line = f'# {today}  {assumption_id} updated: "{_yaml_dquote(excerpt)}"  — {owner}\n'
    if _find_changelog_idx(lines) is None:
        lines.append('# ── Change Log (required: one entry per edit) ─────────\n')
    lines.append(log_line)

    with open(config_path, 'w') as f:
        f.writelines(lines)

    # Write configuration snapshot
    _write_config_snapshot()

    return {"success": True}


@app.delete("/assumptions/{assumption_id}")
def delete_assumption(assumption_id: str):
    """Comment out an assumption in the YAML file (soft delete).

    Appends a change-log entry, consistent with create/update/restore.
    """
    from datetime import date

    config_path = pathlib.Path("/app/config/positioning_assumptions.yaml")

    with open(config_path, 'r') as f:
        lines = f.readlines()

    # Find the assumption block and comment it out
    new_lines = []
    in_target_block = False
    block_lines = []
    today = date.today().isoformat()
    found = False

    for i, line in enumerate(lines):
        if f'id: {assumption_id}' in line or f'id: "{assumption_id}"' in line:
            found = True
            in_target_block = True
            block_lines = [f'  # DELETED: {today}\n']
            block_lines.append('  # ' + line.lstrip())
            continue

        if in_target_block:
            if line.strip() and not line.strip().startswith('-') and line.startswith('  '):
                block_lines.append('  # ' + line.lstrip())
            else:
                new_lines.extend(block_lines)
                new_lines.append(line)
                in_target_block = False
                block_lines = []
        else:
            new_lines.append(line)

    if not found:
        return {"success": False, "error": "Assumption not found"}

    log_line = f'# {today}  {assumption_id} deleted (soft).\n'
    if _find_changelog_idx(new_lines) is None:
        new_lines.append('# ── Change Log (required: one entry per edit) ─────\n')
    new_lines.append(log_line)

    with open(config_path, 'w') as f:
        f.writelines(new_lines)

    # Write configuration snapshot
    _write_config_snapshot()

    return {"success": True}


@app.post("/config/snapshot")
def create_config_snapshot():
    """Manually trigger a configuration snapshot write to Prism-config.md."""
    try:
        path = _write_config_snapshot()
        return {"success": True, "path": path}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.post("/assumptions/{assumption_id}/restore")
def restore_assumption(assumption_id: str):
    """Restore a commented-out assumption (uncomment it).

    Locates the "# DELETED: <date>" marker followed by the commented
    "# - id: <id>" line, reconstructs original indentation (2 spaces for
    the "- id:" line, 4 spaces for other fields), drops the DELETED
    marker, and appends a change-log entry.
    """
    from datetime import date

    config_path = pathlib.Path("/app/config/positioning_assumptions.yaml")

    with open(config_path, 'r') as f:
        lines = f.readlines()

    new_lines = []
    in_target_block = False
    found = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if (not found and line.strip().startswith('# DELETED:')
                and i + 1 < len(lines)):
            next_stripped = lines[i + 1].strip()
            inner = next_stripped.lstrip('#').strip()
            if inner in (f'- id: {assumption_id}', f'- id: "{assumption_id}"'):
                found = True
                in_target_block = True
                new_lines.append('  ' + inner + '\n')
                i += 2
                continue

        if in_target_block:
            stripped = line.strip()
            if stripped.startswith('#'):
                inner = stripped.lstrip('#').strip()
                if inner:
                    new_lines.append('    ' + inner + '\n')
                i += 1
                continue
            else:
                in_target_block = False
                new_lines.append(line)
                i += 1
                continue

        new_lines.append(line)
        i += 1

    if not found:
        return {"success": False, "error": "Assumption not found or not deleted"}

    today = date.today().isoformat()
    log_line = f'# {today}  {assumption_id} restored.\n'
    if _find_changelog_idx(new_lines) is None:
        new_lines.append('# ── Change Log (required: one entry per edit) ─────\n')
    new_lines.append(log_line)

    with open(config_path, 'w') as f:
        f.writelines(new_lines)

    # Write configuration snapshot
    _write_config_snapshot()

    return {"success": True}
